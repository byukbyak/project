// 에러메세지
let insertError = "회원가입에 실패했습니다. \n 다시 시도해주세요.";
let updateError = "회원정보 수정에 실패했습니다. \n 다시 시도해주세요.";
let deleteError = "회원탈퇴에 실패했습니다. \n 다시 시도해주세요.";
let passwordError = "비밀번호가 틀렸습니다. \n 다시 시도해주세요.";

function errorAlert(errorMsg){
	alert(errorMsg);
	window.history.back();
}
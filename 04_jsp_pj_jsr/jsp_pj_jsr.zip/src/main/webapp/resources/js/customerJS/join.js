/* 회원가입 validation check */

//필수항목 체크
function signInCheck(){
   
   //id
   if(!document.joinform.id.value){
      alert("아이디를 입력해주세요.");
      document.joinform.id.focus();
      return false;
     
   //password      
   } else if(!document.joinform.password.value){
      alert("비밀번호를 입력해주세요.");
      document.joinform.password.focus();
      return false;
      
   //repassword 
   } else if(!document.joinform.repassword.value){
      alert("비밀번호 확인란을 입력해주세요.");
      document.joinform.repassword.focus();
      return false;
      
   //password repassword 일치 여부 체크   
   } else if(document.joinform.repassword.value!=document.joinform.password.value){
      alert("비밀번호가 일치하지 않습니다. 다시 입력해주세요.");
      document.joinform.repassword.focus();
      return false;
      
   //name   
   } else if(!document.joinform.name.value){
      alert("이름을 입력해주세요.");
      document.joinform.name.focus();
      return false;
      
   //birthday   
   } else if(!document.joinform.birthday.value){
      alert("생일을 입력해주세요.");
      document.joinform.birthday.focus();
      return false;
   //address   
   } else if(!document.joinform.address.value){
      alert("주소를 입력해주세요.");
      document.joinform.address.focus();
      return false;

   //email      
   } else if(!document.joinform.email1.value){
      alert("이메일을 입력해주세요.");
      document.joinform.email1.focus();
      return false;
      
   //email 형식 불일치   
   } else if(!document.joinform.email2.value && document.joinform.email3.value == 0){
      alert("이메일 형식에 맞지 않습니다. 다시 입력해주세요.");
      document.joinform.email2.focus();
      return false;
   
   //중복 확인 2단계. 중복 확인 버튼 클릭하지 않은 경우 "중복 확인해 주세요."         
   } else if(document.joinform.hiddenId.value =="0"){
      alert("아이디를 중복 확인해주세요.");
      document.joinform.dupChk.focus();
      return false;
   }
}

//아이디 중복 확인
function confirmId(){
   if(!document.joinform.id.value){
   alert("아이디를 입력해주세요.");
   document.joinform.id.focus();
   return false;
   }
   
   //중복 확인 페이지 열기(중복 확인 1단계)
   var url = "/jsp_pj_jsr/id_check.cu?id=" + document.joinform.id.value;
   window.open(url, "confirm", "menubar=no, width=400, height=120"); //window.open(url, "별칭1", size);
}

//이메일 주소를 select 박스로 선택
function selectEmailChk(){
   //직접 입력이 아닌 경우 email.value를 email.value로 초기화
   if(document.joinform.email3!=0){
       document.joinform.email2.value = document.joinform.email3.value;   
   
   //직접 입력 - email2로 초기화
   } else{
      document.joinform.email2.value="";
      document.joinform.email2.focus();
   }
   
}

//중복 확인
//3. 중복 확인 창 포커스
function confirmIdFocus(){
   document.confirmform.id.focus();
}

function confirmIdCheck(){
   if(!document.joinform.id.value){
   alert("아이디를 입력해주세요.");
   document.joinform.id.focus();
   return false;
   }
}

//4. 자식 창에서 부모 창으로 id 값을 전달
// opener: window 객체의 open() 메서드로 열린 새 창(=중복 확인 창)에서 
//         부모 창(=회원 가입 폼)에 접근할 때 사용
function setId(id){
   opener.document.joinform.id.value=id;
   opener.document.joinform.hiddenId.value ="1";
   self.close();
}
/* 관리자 게시글 삭제시 사용 (작은창) */

// 관리자 인증 창 포커스
function certifiedFocus(){
    document.certifiedform.pw.focus();
}

function certifiedCheck(){
    if(!document.certifiedform.pw.value){
    alert("관리자 비밀번호를 입력해주세요.");
    document.certifiedform.pw.focus();
    return false;
    }
}

//4. 자식 창에서 부모 창으로 id 값을 전달
// opener: window 객체의 open() 메서드로 열린 새 창에서 
//         부모 창(=회원 가입 폼)에 접근할 때 사용
// 인증이 필요한 부모창에 있어야하는 것 : <input type="hidden" name="hiddenPW" value="${hiddenPW}" >
function setPW(pw){
    opener.document.certifiedform.pw.value=pw;
    opener.document.certifiedform.hiddenPW.value ="1";
    self.close();
}
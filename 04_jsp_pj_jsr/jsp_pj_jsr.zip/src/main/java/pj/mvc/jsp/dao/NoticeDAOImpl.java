package pj.mvc.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import pj.mvc.jsp.dto.NoticeDTO;

public class NoticeDAOImpl implements NoticeDAO {

	// 1. 싱글톤
	static NoticeDAOImpl instance = new NoticeDAOImpl();
	public static NoticeDAOImpl getInstance() {
		if(instance == null) {
			instance = new NoticeDAOImpl();
		} return instance;
	}

	// 2. 커넥션 풀 객체를 보관
	DataSource dataSource;

	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql;

	// 3. 디폴트 생성자
	private NoticeDAOImpl() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/jsp_pj_jsr");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}

	// 4. 자원해제 메서드
	public void close_all() {
		try {
			if(rs != null) rs.close();
			if(pstmt != null) pstmt.close();
			if(conn != null) conn.close();
			if(sql != null) sql=null;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override // 게시글 개수
	public int noticeCnt() {
		System.out.println("DAO - noticeCnt");

		int cnt = 0;

		try {
			conn = dataSource.getConnection();
			sql="SELECT COUNT(*) as cnt FROM mvc_notice_tbl";
			pstmt = conn.prepareStatement(sql);

			rs = pstmt.executeQuery();
			if(rs.next()) cnt = rs.getInt("cnt");

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return cnt;
	}

	@Override // 조회수 증가
	public int plusReadCnt(int num) {
		System.out.println("DAO - plusReadCnt");

		int plusReadCntResult = 0;

		try {
			conn = dataSource.getConnection();
			sql = "UPDATE mvc_notice_tbl SET readCnt=readCnt+1 WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			plusReadCntResult = pstmt.executeUpdate();
			System.out.println("조회수 : " + plusReadCntResult);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return plusReadCntResult;
	}

	@Override // 게시글 목록
	public List<NoticeDTO> notice_list(int start, int end) {
		System.out.println("DAO - notice_list");

		List<NoticeDTO> list = null;

		try {
			conn = dataSource.getConnection();
			sql = "SELECT * "
				+ "FROM ( SELECT A.*, ROWNUM AS rn "
				+ 		"FROM ( SELECT num, title, content, writer, readCnt, indate "
				+ 				"FROM mvc_notice_tbl "
				+ 				"ORDER BY num DESC ) A "
				+ 				") "
				+ "rs BETWEEN ? AND ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				// 1. list 생성
				list =  new ArrayList<>();
				do {
					// 2. dto 생성
					NoticeDTO dto = new NoticeDTO();

					// 3. dto에 rs 게시글 정보를 담는다.
					dto.setNum(rs.getInt("num"));
					dto.setTitle(rs.getString("title"));
					dto.setContent(rs.getString("content"));
					dto.setWriter(rs.getString("writer"));
					dto.setReadCnt(rs.getInt("readCnt"));
					dto.setIndate(rs.getDate("indate"));
					System.out.println(dto);

					// 4. list에 dto를 추가한다.
					list.add(dto);

				} while(rs.next());
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return list;
	}

	@Override // 게시글 상세
	public NoticeDTO notice_read(int num) {
		System.out.println("DAO - notice_read");

		NoticeDTO dto = new NoticeDTO();

		try {
			conn = dataSource.getConnection();
			sql = "SELECT * FROM mvc_notice_tbl WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			rs = pstmt.executeQuery();

			if(rs.next()) {
				dto.setNum(rs.getInt("num"));
				dto.setTitle(rs.getString("title"));
				dto.setContent(rs.getString("content"));
				dto.setWriter(rs.getString("writer"));
				dto.setReadCnt(rs.getInt("readCnt"));
				dto.setIndate(rs.getDate("indate"));
			}
			System.out.println(dto);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return dto;
	}

	@Override // 공지사항 INSERT
	public int notice_insert(NoticeDTO dto) {
		System.out.println("DAO - notice_insert");
		int insertCnt = 0;

		try {
			conn = dataSource.getConnection();
			sql = "INSERT INTO mvc_notice_tbl(num, title, content, writer) "
				+ "VALUES((SELECT NVL(MAX(num)+1,1) FROM mvc_notice_tbl), ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setString(3, dto.getWriter());

			insertCnt = pstmt.executeUpdate();
			System.out.println("insertCnt : "+insertCnt);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return insertCnt;
	}

	@Override // 공지사항 UPDATE
	public int notice_update(NoticeDTO dto) {
		System.out.println("DAO - notice_update");

		int updateCnt = 0;

		try {
			conn = dataSource.getConnection();
			sql = "UPDATE mvc_notice_tbl SET title=?, content=? WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getTitle());
			pstmt.setString(2, dto.getContent());
			pstmt.setInt(3, dto.getNum());

			updateCnt = pstmt.executeUpdate();
			System.out.println("updateCnt : "+updateCnt);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return updateCnt;
	}

	@Override // 공지사항 DELETE
	public int notice_delete(int num) {
		System.out.println("DAO - notice_delete");

		int deleteCnt = 0;

		try {
			conn = dataSource.getConnection();
			sql = "DELETE mvc_notice_tbl SET SHOW='n' WHERE num=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);

			deleteCnt = pstmt.executeUpdate();
			System.out.println("deleteCnt : "+deleteCnt);

		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			close_all();
		}
		return deleteCnt;
	}

}

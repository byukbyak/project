package pj.mvc.jsp.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface CustomerService {
	// Service는 Controller의 역할을 나눠서 감당하기 때문에 매개변수를 컨트롤러와 일치시켜준다.
	
	// 중복확인 처리
	public void confirmIdAction(HttpServletRequest req, HttpServletResponse res);
	
	// 회원가입 처리
	public void signInAction(HttpServletRequest req, HttpServletResponse res);
	
	// 로그인 처리
	public void LoginAction(HttpServletRequest req, HttpServletResponse res);
	
	// 회원정보 인증 및 탈퇴처리
	public void deleteCustomerAction(HttpServletRequest req, HttpServletResponse res);
	
	// 회원정보 인증 및 상세페이지
	public void modifyDetailAction(HttpServletRequest req, HttpServletResponse res);
	
	// 회원정보 수정 처리
	public void modifyCustomerAction(HttpServletRequest req, HttpServletResponse res);

}

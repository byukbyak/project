package pj.mvc.jsp.dao;

import java.util.List;

import pj.mvc.jsp.dto.ProductDTO;

public interface ProductDAO {

	// 상품 개수
	int productCount();
	
	// 상품 목록
	List<ProductDTO> productList(int start, int end);
	
	// 상품 상세페이지
	ProductDTO productRead(int p_code);
	
	// 상품 추가
	int productInsert(ProductDTO dto);
	
	// 상품 수정
	int productUpdate(ProductDTO dto);
	
	// 상품 삭제
	int productDelete(int p_code);
	
	
}

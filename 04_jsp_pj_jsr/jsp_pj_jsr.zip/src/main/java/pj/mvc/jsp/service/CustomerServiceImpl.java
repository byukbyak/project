package pj.mvc.jsp.service;


import java.sql.Date;
import java.sql.Timestamp;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.dao.CustomerDAO;
import pj.mvc.jsp.dao.CustomerDAOImpl;
import pj.mvc.jsp.dto.CustomerDTO;

public class CustomerServiceImpl implements CustomerService{

	// 중복확인 처리
	@Override
	public void confirmIdAction(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("서비스 => 중복확인 처리");
		
		// 3단계. 화면으로부터 입력받은 값을 받아서 DTO에 담는다. (입력된 아이디값)
		String strId = req.getParameter("id"); // jsp단에서 입력받은 input 태그명이 ("여기")에 들어온다.
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5단계. 중복확인 처리
		int selectCnt = dao.idCheck(strId);
		System.out.println("selectCnt"+selectCnt);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("id", strId); //id라는 이름으로 컨트롤러 -> jsp로 보냄.
		req.setAttribute("selectCnt", selectCnt); // (DAO의 executeQuery결과가 0:조회실패=중복아님 아니면 1:조회성공=중복있음이 담겨있음)
	}
	
	
	// 회원가입 처리
	@Override
	public void signInAction(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("서비스 => 회원가입처리");
		
		// 3단계. 화면으로부터 입력받은 값을 받아서 DTO에 담는다.
		// DTO 생성
		CustomerDTO dto = new CustomerDTO();
		
		dto.setId(req.getParameter("id"));
		dto.setPassword(req.getParameter("password"));
		dto.setName(req.getParameter("name"));
		dto.setNickname(req.getParameter("nickname"));
		String strDate = req.getParameter("birthday");
		Date date = Date.valueOf(strDate);
		dto.setBirthday(date);
		dto.setAddress(req.getParameter("address"));

		// 핸드폰
		String hp = "";
		String strHp1 = req.getParameter("hp1");
		String strHp2 = req.getParameter("hp2");
		String strHp3 = req.getParameter("hp3");
		
		if(!strHp1.equals("") && !strHp2.equals("") && !strHp3.equals("")) {
			hp = strHp1 + "-" + strHp2 + "-" + strHp3;
		}
		dto.setHp(hp);
		
		// 이메일 값 입력하는곳이 2개이므로 이어주기
		String email = "";
		String strEmail1 = req.getParameter("email1");
		String strEmail2 = req.getParameter("email2");
		email = strEmail1 + "@" + strEmail2;
		dto.setEmail(email);
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5단계. 회원가입 처리
		int insertCnt = dao.insertCustomer(dto);
		System.out.println("서비스 insertCnt : "+insertCnt);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("insertCnt", insertCnt);
		// login.jsp 에서 key값인 insertCnt 활용해서 값을 전달한다.
	}
	
	// 로그인 처리
	@Override
	public void LoginAction(HttpServletRequest req, HttpServletResponse res) {
		
		// 3단계. 화면에서 입력받은 값 받아오기
		String strId = req.getParameter("id");
		String strPw = req.getParameter("password");
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5단계. 로그인 처리
		int selectCnt = dao.idPasswordChk(strId, strPw);
		String nickname = dao.getNickName(strId);
		
		// 5-1. 로그인 성공
		if(selectCnt == 1) {
			// 로그인 성공시 세션 ID를 설정
			req.getSession().setAttribute("customerID", strId);
			req.getSession().setAttribute("nickname", nickname);
		}
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("selectCnt", selectCnt);
	}

	// 회원정보 수정 처리
	@Override
	public void modifyCustomerAction(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 화면으로부터 입력받은 값을 받아서 DTO에 담는다.
		
		CustomerDTO dto = new CustomerDTO();
		dto.setId((String)req.getSession().getAttribute("customerID"));
		dto.setPassword(req.getParameter("password"));
		dto.setName(req.getParameter("name"));
		dto.setNickname(req.getParameter("nickname"));
		String strBirthday = req.getParameter("birthday");
		Date birthday = Date.valueOf(strBirthday);
		dto.setBirthday(birthday);
		dto.setAddress(req.getParameter("address"));
		
		String hp = "";
		String hp1 = req.getParameter("hp1");
		String hp2 = req.getParameter("hp2");
		String hp3 = req.getParameter("hp3");
		if(!hp1.equals("") && !hp2.equals("") && !hp3.equals("")) {
			hp = hp1+"-"+hp2+"-"+hp3;
		}
		dto.setHp(hp);
		
		String email = "";
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		if(!email1.equals("") && !email2.equals("")) {
			email = email1+"@"+email2;
		}
		dto.setEmail(email);
		
		System.out.println("dto.getPassword() : "+dto.getPassword());
		System.out.println("dto.getName() : "+dto.getName());
		System.out.println("dto.getNickname() : "+dto.getNickname());
		System.out.println("dto.getBirthday() : "+dto.getBirthday());
		System.out.println("dto.getAddress() : "+dto.getAddress());
		System.out.println("dto.getHp() : "+dto.getHp());
		System.out.println("dto.getEmail() : "+dto.getEmail());
		System.out.println("dto.getId() : "+dto.getId());
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5단계. 회원수정 처리
		int updateCnt = dao.updateCustomer(dto);
		System.out.println("updateCnt : "+updateCnt);
		
		// 6단계. jsp로 처리 결과 전달
		req.setAttribute("updateCnt", updateCnt);
		
	}
	
	// 회원정보 인증 및 상세페이지
	@Override
	public void modifyDetailAction(HttpServletRequest req, HttpServletResponse res) {
		// 3단계. 화면에서 입력받은 값 받아오기
		String strId = (String)req.getSession().getAttribute("customerID"); // 세션ID - 왜냐? 이미 입력된거 화면에 띄워줄려고
		String strPw = req.getParameter("password"); // 인풋에서 입력받은 PW - 왜냐? 이 비밀번호가 맞는지 아닌지 확인해줄려고
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5-1단계. 회원정보수정을 위한 회원인증 처리
		int selectCnt = dao.idPasswordChk(strId, strPw);
		System.out.println("수정서비스 selectCnt : "+ selectCnt);
		
		CustomerDTO dto = null;
		// 5-2단계. 회원인증 성공시 상세정보 조회
		if(selectCnt == 1) {
			dto = dao.getCustomerDetail(strId);
		}
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("selectCnt", selectCnt);
		req.setAttribute("dto", dto);
	}
	
	// 회원정보 인증 및 탈퇴처리
	@Override
	public void deleteCustomerAction(HttpServletRequest req, HttpServletResponse res) {
		int deleteCnt = 0;
		// 3단계. 입력값 전달받기
		String strId = (String)req.getSession().getAttribute("customerID");
		String strPw = req.getParameter("password");
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		CustomerDAO dao = CustomerDAOImpl.getInstance();
		
		// 5-1단계. 회원탈퇴를 위한 회원인증처리
		int selectCnt = dao.idPasswordChk(strId, strPw);
		System.out.println("탈퇴서비스 selectCnt : "+ selectCnt);
		
		// 5-2단계. 인증성공시 회원탈퇴진행
		if(selectCnt == 1) {
			deleteCnt = dao.deleteCustomer(strId);
			System.out.println("탈퇴서비스 deleteCnt : "+deleteCnt);
		}
		
		// 6단계. jsp로 결과 전달
		req.setAttribute("deleteCnt", deleteCnt);
	}
	
}

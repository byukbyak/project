package pj.mvc.jsp.util;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

public class ImageUploaderHandler {
	
	private String uploadPath;

	public void setUploadPath(String url) {
		this.uploadPath = url;
	}
	
	public void imageUpload(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException{
		
		req.setCharacterEncoding("UTF-8");
		
		File UploadDir = new File(uploadPath);
		
		if(!UploadDir.exists()) {
			UploadDir.mkdir();
		}
		
		try {
			UploadDir.setWritable(true);
			UploadDir.setReadable(true);
			UploadDir.setExecutable(true);
			
			String fileName = "";
			for(Part part : req.getParts()){
				System.out.println(part.getHeader("content-disposition"));
				fileName = getFileName(part);
				if(fileName != null && !"".equals(fileName)) {
					part.write(uploadPath + File.separator + fileName);
					req.setAttribute("fileName", fileName);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		res.setContentType("text/html");
		res.getWriter().println("===업로드 완료===");
	}
	
	private String getFileName(Part part) {
		for(String content : part.getHeader("content-disposition").split(";")) {
			if(content.trim().startsWith("filename")) {
				return content.substring(content.indexOf("=")+2, content.length() -1);
			}
		}
		return null; // filename이 없는 경우(폼필드가 데이터인 경우);
	}
}

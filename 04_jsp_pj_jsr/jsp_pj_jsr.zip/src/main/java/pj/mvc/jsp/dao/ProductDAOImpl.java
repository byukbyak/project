package pj.mvc.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import pj.mvc.jsp.dto.ProductDTO;

public class ProductDAOImpl implements ProductDAO {

	// 1. 싱글톤
	static ProductDAOImpl instance = new ProductDAOImpl();
	public static ProductDAOImpl getInsetance() {
		if(instance == null) {
			instance = new ProductDAOImpl();
		}
		return instance;
	}
	
	// 2. 커넥션 풀 객체를 보관
	DataSource dataSource;
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	// 3. 디폴트 생성자
	private ProductDAOImpl() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/jsp_pj_jsr");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public List<ProductDTO> productList(int start, int end) {
		System.out.println("DAO - productList()");
		
		List<ProductDTO> list = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * "
					+ "  FROM ( "
					+ "       SELECT A.*, ROWNUM AS rn "
					+ "         FROM ( "
					+ "                SELECT p_code, p_brand, p_category, p_name, p_content, p_img, p_price, p_qty, indate, outdate, status "
					+ "                  FROM mvc_product_tbl "
					+ "                 ORDER BY p_code DESC "
					+ "                 ) A "
					+ "       ) "
					+ " WHERE rn BETWEEN ? AND ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, end);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				// 1. list 생성
				list = new ArrayList<ProductDTO>();
				
				do {
					// 2. dto 생성
					ProductDTO dto = new ProductDTO();
					
					// 3. dto에 rs 게시글 정보를 담는다.
					dto.setP_code(rs.getInt("p_code"));
					dto.setP_brand(rs.getString("p_brand"));
					dto.setP_category(rs.getString("p_category"));
					dto.setP_name(rs.getString("p_name"));
					dto.setP_content(rs.getString("p_content"));
					dto.setP_img(rs.getString("p_img"));
					dto.setP_price(rs.getInt("p_price"));
					dto.setP_qty(rs.getInt("p_qty"));
					dto.setIndate(rs.getDate("indate"));
					dto.setOutdate(rs.getDate("outdate"));
					dto.setStatus(rs.getString("status"));
					
					// 4. list에 dto를 추가한다.
					list.add(dto);
					
				} while(rs.next());
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public ProductDTO productRead(int p_code) {
		System.out.println("DAO - getProductDetail()");
		ProductDTO dto = null;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_product_tbl WHERE p_code=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_code);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				dto = new ProductDTO();
				// dto에 rs 게시글 정보를 담는다.
				dto.setP_code(rs.getInt("p_code"));
				dto.setP_brand(rs.getString("p_brand"));
				dto.setP_category(rs.getString("p_category"));
				dto.setP_name(rs.getString("p_name"));
				dto.setP_content(rs.getString("p_content"));
				dto.setP_img(rs.getString("p_img"));
				dto.setP_price(rs.getInt("p_price"));
				dto.setP_qty(rs.getInt("p_qty"));
				dto.setP_option(rs.getString("p_option"));
				dto.setIndate(rs.getDate("indate"));
				dto.setOutdate(rs.getDate("outdate"));
				dto.setStatus(rs.getString("status"));
				
				System.out.println(dto);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return dto;
	}

	@Override
	public int productInsert(ProductDTO dto) {
		System.out.println("DAO - productInsert()");
		int insertCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "INSERT INTO mvc_product_tbl (p_code, p_brand, p_category, p_name, p_content, p_img, p_price, p_qty, status) "
					+ "VALUES((SELECT NVL(MAX(p_code)+1,1) FROM mvc_product_tbl), ?, ?, ?, ?, ?, ?, ?, ?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getP_brand());
			pstmt.setString(2, dto.getP_category());
			pstmt.setString(3, dto.getP_name());
			pstmt.setString(4, dto.getP_content());
			pstmt.setString(5, dto.getP_img());
			pstmt.setInt(6, dto.getP_price());
			pstmt.setInt(7, dto.getP_qty());
			pstmt.setString(8, dto.getStatus());
			
			insertCnt = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}

	@Override
	public int productUpdate(ProductDTO dto) {
		System.out.println("DAO - productUpdate()");
		int updateCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "UPDATE mvc_product_tbl "
					+ "SET p_brand=?, p_category=?, p_name=?, p_content=?, p_img=?, p_price=?, p_qty=?, status=? "
					+ "WHERE p_code=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getP_brand());
			pstmt.setString(2, dto.getP_category());
			pstmt.setString(3, dto.getP_name());
			pstmt.setString(4, dto.getP_content());
			pstmt.setString(5, dto.getP_img());
			pstmt.setInt(6, dto.getP_price());
			pstmt.setInt(7, dto.getP_qty());
			pstmt.setString(8, dto.getStatus());
			pstmt.setInt(9, dto.getP_code());
			
			updateCnt = pstmt.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return updateCnt;
	}

	@Override
	public int productDelete(int p_code) {
		System.out.println("DAO - productDelete()");
		int deleteCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "DELETE FROM mvc_product_tbl WHERE p_code=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, p_code);
			
			deleteCnt = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return deleteCnt;
	}

	@Override // 상품 개수 구하기
	public int productCount() {
		System.out.println("DAO - productCount()");
		
		int selectCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT COUNT(*) as cnt FROM mvc_product_tbl";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				selectCnt = rs.getInt("cnt");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}

}

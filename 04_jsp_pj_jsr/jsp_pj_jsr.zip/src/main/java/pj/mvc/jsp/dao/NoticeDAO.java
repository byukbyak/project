package pj.mvc.jsp.dao;

import java.util.List;

import pj.mvc.jsp.dto.NoticeDTO;

public interface NoticeDAO {
	
	// 게시글 개수
	public int noticeCnt();
	
	// 조회수 증가
	int plusReadCnt(int num);
	
	// 게시글 목록
	List<NoticeDTO> notice_list(int start, int end);
	
	// 게시글 상세
	NoticeDTO notice_read(int num);
	
	// 공지사항 INSERT
	int notice_insert(NoticeDTO dto);
	
	// 공지사항 UPDATE
	int notice_update(NoticeDTO dto);
	
	// 공지사항 DELETE
	int notice_delete(int num);
	
}

package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.service.ProductServiceImpl;
import pj.mvc.jsp.util.ImageUploaderHandler;

@WebServlet("*.st")
@MultipartConfig(location="D:\\Dev105\\workspace\\jsp_pj_jsr\\src\\main\\webapp\\resources\\upload",
fileSizeThreshold = 1024*1024, maxFileSize = 1024*1024*5, maxRequestSize = 1024*1024*5*5)
public class StockController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String IMG_UPLOAD_DIR="D:\\Dev105\\workspace\\jsp_pj_jsr\\src\\main\\webapp\\resources\\upload";
	private ImageUploaderHandler uploader;
	
	// 1단계. 웹브라우저가 전송한 HTTP 요청 받음
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		action(req, res);
	}
	
	// 1단계. 웹브라우저가 전송한 HTTP 요청 받음
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
	
	public void getDispatcherForward(HttpServletRequest req, HttpServletResponse res, String viewPage)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
	}
	
	public void action(HttpServletRequest req,HttpServletResponse res)
			throws ServletException, IOException {
		
		// 한글처리
		req.setCharacterEncoding("UTF-8");
		res.setContentType("text/html;charset=utf-8");
		String viewPage = ""; // 페이지 결과를 받을 변수 선언
		
		// BoardService 객체 생성
		ProductServiceImpl service = new ProductServiceImpl();
		
		String uri = req.getRequestURI(); // request받은 URI를 받을 변수 선언
		String contextPath = req.getContextPath(); // 프로젝트명 가져오는 메서드
		String url = uri.substring(contextPath.length());
		
		// 2단계. 요청분석
		// 관리자 메인 (상품목록)
		if(url.equals("/*.st") || url.equals("/product_list.st")) {
	        System.out.println("[url ==> /product_list.st]");
	        service.productListAction(req, res);
	        viewPage = "manager/stock/product_list.jsp";
	        getDispatcherForward(req, res, viewPage);
		}
		// 상품 추가 페이지
		else if(url.equals("/product_add.st")) {
			System.out.println("[url ==> /product_add.st]");
			viewPage = "/manager/stock/product_add.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 상품 추가 Insert
		else if(url.equals("/product_insert.st")) {
			System.out.println("[url ==> /product_insert.st]");
			
			String contentType = req.getContentType();
			if(contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
				uploader = new ImageUploaderHandler();
				uploader.setUploadPath(IMG_UPLOAD_DIR);
				uploader.imageUpload(req, res);
			}
			
			service.productAddAction(req, res);
			viewPage = "/manager/stock/product_add_chk.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 상품 상세페이지
		else if(url.equals("/product_read.st")) {
			System.out.println("[url ==> /product_read.st]");
			
			service.productReadAction(req, res);
			viewPage = "/manager/stock/product_read.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 상품정보 수정 화면
		else if(url.equals("/product_update.st")) {
			System.out.println("[url ==> /product_update.st]");
			
			service.productReadAction(req, res);
			viewPage = "/manager/stock/product_update.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 상품정보 UPDATE
		else if(url.equals("/product_update_action.st")) {
			System.out.println("[url ==> /product_update_action.st]");
			
			String contentType = req.getContentType();
			if(contentType != null && contentType.toLowerCase().startsWith("multipart/")) {
				uploader = new ImageUploaderHandler();
				uploader.setUploadPath(IMG_UPLOAD_DIR);
				uploader.imageUpload(req, res);
			}
			
			service.productUpdateAction(req, res);
			viewPage = "/manager/stock/product_list.jsp";
			res.sendRedirect(viewPage);
		}
		// 상품정보 삭제
		else if(url.equals("/product_delete.st")) {
			System.out.println("[url ==> /product_delete.st]");
			service.productDeleteAction(req, res);
			viewPage = req.getContextPath() +"/product_list.st";
			res.sendRedirect(viewPage);
		}
	}
}

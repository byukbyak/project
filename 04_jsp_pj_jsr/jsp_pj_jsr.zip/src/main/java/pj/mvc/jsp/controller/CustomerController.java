package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.service.CustomerServiceImpl;

@WebServlet("*.cu")
public class CustomerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		action(req, res);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}

	public void getDispatcherForward(HttpServletRequest req, HttpServletResponse res, String viewPage)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
	}

	public void action(HttpServletRequest req,HttpServletResponse res)
			throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		res.setContentType("text/html;charset=utf-8");
		String viewPage = "";

		CustomerServiceImpl service = new CustomerServiceImpl();

		String uri = req.getRequestURI(); // request받은 URI를 받을 변수 선언
		String contextPath = req.getContextPath();
		String url = uri.substring(contextPath.length());

		/* ---------------------------- [main] ---------------------------- */
		if(url.equals("/*.cu") || url.equals("/main.cu")) {
         System.out.println("[url : main.cu]");
         viewPage = "index.jsp";
         getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [join] ---------------------------- */
		// 회원가입 페이지
		else if(url.equals("/join.cu")) {
			System.out.println("[url : join.cu]");
			viewPage = "customer/join/join.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 아이디 중복확인(작은 창)
		else if(url.equals("/id_check.cu")) {
			System.out.println("[url : id_check.cu]");
			service.confirmIdAction(req, res);
			viewPage = "customer/join/id_check.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 회원가입 INSERT
		else if(url.equals("/join_insert.cu")) {
			System.out.println("[url : join_insert.cu]");
			service.signInAction(req, res);
			viewPage = "customer/join/join_insert.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [login] ---------------------------- */
		// 로그인 화면
		else if(url.equals("/login.cu")) {
			System.out.println("[url : login.cu]");
			viewPage = "customer/login/login.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 로그인 처리
		else if(url.equals("/login_action.cu")) {
			System.out.println("[url : login_action.cu]");
			service.LoginAction(req, res);
			viewPage = "customer/login/login_action.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 로그아웃 페이지
		else if(url.equals("/logout.cu")) {
			System.out.println("[url : logout.cu]");
			req.getSession().invalidate(); // 일괄 세션 삭제
			viewPage = "index.jsp";
			res.sendRedirect(viewPage);
		}
		/* ---------------------------- [member_update] ---------------------------- */
		// 회원수정 - 인증화면
		else if(url.equals("/modify_check.cu")) {
			System.out.println("[url : modify_check.cu]");
			viewPage = "customer/mypage/customerInfo/modify_check.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 회원정보 상세페이지
		else if(url.equals("/modify_read.cu")) {
			System.out.println("[url : modify_read.cu]");
			service.modifyDetailAction(req, res);
			viewPage = "customer/mypage/customerInfo/modify_read.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 회원정보 수정완료시
		else if(url.equals("/modify_update.cu")) {
			System.out.println("[url : modify_update.cu]");
			service.modifyCustomerAction(req, res);
			viewPage = "customer/mypage/customerInfo/modify_update.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [member_delete] ---------------------------- */
		// 회원탈퇴 - 인증화면
		else if(url.equals("/delete_check.cu")) {
			System.out.println("[url : delete_check.cu]");
			viewPage = "customer/mypage/customerInfo/delete_check.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 회원탈퇴 - 인증완료
		else if(url.equals("/delete_action.cu")) {
			System.out.println("[url : delete_action.cu]");
			service.deleteCustomerAction(req, res);
			viewPage = "customer/mypage/customerInfo/delete_action.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [상품목록] ---------------------------- */
		// 상품목록 - 카테고리별 불러오기 (전체/)
		else if(url.equals("/goods_list.cu")) {
			System.out.println("[url : goods_list.cu]");
			service.deleteCustomerAction(req, res);
			viewPage = "customer/goods/goods_list.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 상품목록 - 카테고리별 불러오기
		else if(url.equals("/goods_list.cu")) {
			System.out.println("[url : goods_list.cu]");
			service.deleteCustomerAction(req, res);
			viewPage = "customer/goods/goods_list.jsp";
			getDispatcherForward(req, res, viewPage);
		}

	}
}
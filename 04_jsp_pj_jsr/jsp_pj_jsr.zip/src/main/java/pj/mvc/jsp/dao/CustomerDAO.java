package pj.mvc.jsp.dao;

import pj.mvc.jsp.dto.CustomerDTO;
/*  [DAO(Data Access Object)]
	데이터베이스의 데이터에 접근하기 위한 객체!
	데이터베이스에 접근하기 위한 로직(?)과 비즈니스 로직을 분리하기 위해 사용한다!
	간단하겐s DB에 접속하여 데이터의 CRUD 작업을 시행하는 클래스이다.
*/
public interface CustomerDAO {

	// ID 중복확인 처리
	public int idCheck(String strId);
	
	// 회원가입 처리
	public int insertCustomer(CustomerDTO dto);
	
	// 로그인 처리 / 회원정보 인증(수정, 탈퇴)
	public int idPasswordChk(String strId, String strPassword);
	
	// 회원정보 인증 및 탈퇴처리
	public int deleteCustomer(String strId);
	
	// 회원정보 인증 및 상세페이지
	public CustomerDTO getCustomerDetail(String strId);
	
	// 회원정보 수정 처리
	public int updateCustomer(CustomerDTO dto);
	
	// 닉네임 가져오기
	public String getNickName(String strId);
}

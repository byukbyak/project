package pj.mvc.jsp.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import page.Paging;
import pj.mvc.jsp.dao.ProductDAO;
import pj.mvc.jsp.dao.ProductDAOImpl;
import pj.mvc.jsp.dto.ProductDTO;

public class ProductServiceImpl implements ProductService{

	@Override // 상품추가
	public void productAddAction(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - productAddAction()");
		
		// 3단계. 화면에서 입력받은 값 받아오기 > DTO에 담기
		ProductDTO dto = new ProductDTO();
		dto.setP_brand(req.getParameter("p_brand"));
		dto.setP_category(req.getParameter("p_category"));
		dto.setP_name(req.getParameter("p_name"));
		dto.setP_content(req.getParameter("p_content"));
		// 플젝명/upload 파일업로드 경로
		String path_img = "/jsp_pj_jsr/resources/upload/"+(String)req.getAttribute("fileName");
		dto.setP_img(path_img);
		dto.setP_price(Integer.parseInt(req.getParameter("p_price")));
		dto.setP_qty(Integer.parseInt(req.getParameter("p_qty")));
		dto.setStatus(req.getParameter("status"));
		
		System.out.println("서비스 dto insert 정보 - "+dto.toString());
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInsetance();
		
		// 5단계. 상품정보 Insert
		int insertCnt = dao.productInsert(dto);
		System.out.println("서비스 - insertCnt : "+insertCnt);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("insertCnt", insertCnt);
	}

	@Override // 상품수정
	public void productUpdateAction(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - productUpdateAction()");

		// 3단계. 화면에서 입력받은 값 받아오기
		ProductDTO dto = new ProductDTO();
		dto.setP_code(Integer.parseInt(req.getParameter("p_code")));
		dto.setP_brand(req.getParameter("p_brand"));
		dto.setP_category(req.getParameter("p_category"));
		dto.setP_name(req.getParameter("p_name"));
		dto.setP_content(req.getParameter("p_content"));
		
		// 플젝명/upload 파일업로드 경로
		String path_img = "/jsp_pj_jsr/resources/upload/"+(String)req.getAttribute("fileName");
		dto.setP_img(path_img);
		dto.setP_price(Integer.parseInt(req.getParameter("p_price")));
		dto.setP_qty(Integer.parseInt(req.getParameter("p_qty")));
		dto.setP_option(req.getParameter("p_option"));
		dto.setStatus(req.getParameter("status"));
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInsetance();
		
		// 5단계.
		int updateCnt = dao.productUpdate(null);
		System.out.println("서비스 updateCnt : "+updateCnt);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("updateCnt", updateCnt);
	}

	@Override // 상품삭제
	public void productDeleteAction(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - productDeleteAction()");

		// 3단계. 화면에서 입력받은 값 받아오기
		int p_code = Integer.parseInt(req.getParameter("p_code"));
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInsetance();
		
		// 5단계.
		int deleteCnt = dao.productDelete(p_code);
		System.out.println("서비스 deleteCnt : "+deleteCnt);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("deleteCnt", deleteCnt);
	}

	@Override // 상품목록
	public void productListAction(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - productListAction()");

		// 3단계. 화면에서 입력받은 값 받아오기
		String pageNum = req.getParameter("pageNum");
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInsetance();
		
		// 5단계. 페이지 처리
		Paging paging = new Paging(pageNum);
		
		// 전체 게시글 개수
		int total = dao.productCount();
		System.out.println("total : "+total);
		paging.setTotalCount(total);
		
		int start = paging.getStartRow();
		int end = paging.getEndRow();
		
		List<ProductDTO> list = dao.productList(start, end);
		System.out.println("list : "+list);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("list", list);
		req.setAttribute("paging", paging);
		
	}

	@Override // 상품 상세 정보 불러오기 - 관리자
	public void productReadAction(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - productReadAction()");
		
		// 3단계. 화면에서 입력받은 값 받아오기
		int p_code = Integer.parseInt(req.getParameter("p_code"));
		
		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		ProductDAO dao = ProductDAOImpl.getInsetance();
		
		// 5단계.
		ProductDTO dto = dao.productRead(p_code);
		
		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("dto", dto);
	}
}

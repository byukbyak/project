package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pj.mvc.jsp.service.BoardServiceImpl;
import pj.mvc.jsp.service.NoticeServiceImpl;
import pj.mvc.jsp.service.ProductServiceImpl;

@WebServlet("*.ad")
public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		action(req, res);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}

	public void getDispatcherForward(HttpServletRequest req, HttpServletResponse res, String viewPage)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
	}

	public void action(HttpServletRequest req,HttpServletResponse res)
			throws ServletException, IOException {

		// 한글처리
		req.setCharacterEncoding("UTF-8");
		res.setContentType("text/html;charset=utf-8");
		String viewPage = ""; // 페이지 결과를 받을 변수 선언

		// BoardService 객체 생성
		BoardServiceImpl service = new BoardServiceImpl();
		ProductServiceImpl service_product = new ProductServiceImpl();
		NoticeServiceImpl service_notice = new NoticeServiceImpl();

		String uri = req.getRequestURI(); // request받은 URI를 받을 변수 선언
		String contextPath = req.getContextPath(); // 프로젝트명 가져오는 메서드
		String url = uri.substring(contextPath.length());

		/* ---------------------------- [product] ---------------------------- */
		// 메인/재고목록
		if(url.equals("/*.ad") || url.equals("/main_manager.ad") || url.equals("/product_list.ad")) {
	         System.out.println("[url ==> /product_list.ad");
	         service_product.productListAction(req, res);
	         viewPage = "/manager/common/product_list.jsp";
	         getDispatcherForward(req, res, viewPage);
		}
		// 재고추가 화면
		else if(url.equals("/product_add.ad")) {
			System.out.println("[url ==> /product_add.ad");
			viewPage = "/manager/stock/product_add.jsp";
			// 서비스-재고추가
			getDispatcherForward(req, res, viewPage);
		}
		// 재고추가 INSERT
		else if(url.equals("/product_add.ad")) {
			System.out.println("[url ==> /product_add.ad");
			viewPage = "/manager/stock/product_add.jsp";
			// 서비스-재고추가
			getDispatcherForward(req, res, viewPage);
		}
		// 재고수정
		else if(url.equals("/product_update.ad")) {
			System.out.println("[url ==> /product_update.ad");
			viewPage = "/manager/stock/product_update.jsp";
			// 서비스-재고수정
			getDispatcherForward(req, res, viewPage);
		}
		// 재고삭제
		else if(url.equals("/product_delete.ad")) {
			System.out.println("[url ==> /product_delete.ad");
			//서비스-재고삭제
			viewPage = "/manager/stock/main_manager.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [certified] ---------------------------- */
		// 관리자 인증(아이디 중복확인창같은 작은 창, 게시물 수정,삭제시 사용하고싶음)
		else if(url.equals("/certified.ad")) {
			System.out.println("[url ==> /certified.ad]");
			/* 아이디 중복확인창처럼 인증하고 빛났다 사라졌으면 좋겠는데.. 서비스 만들어야함*/
			viewPage = "manager/common/certified.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [notice] ---------------------------- */
		// 공지사항 목록
		else if(url.equals("/notice_list.ad")) {
			System.out.println("[url ==> /notice_list.ad]");
			service_notice.notice_list_action(req, res);
			viewPage = "manager/notice/notice_list.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 공지사항 상세
		else if(url.equals("/notice_read.ad")) {
			System.out.println("[url ==> /notice_read.ad]");
			service_notice.notice_read_action(req, res);
			viewPage = "manager/notice/notice_read.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 공지사항 등록
		else if(url.equals("/notice_insert.ad")) {
			System.out.println("[url ==> /notice_insert.ad]");
			viewPage = "manager/notice/notice_insert.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 공지사항 INSERT
		else if(url.equals("/notice_insert_action.ad")) {
			System.out.println("[url ==> /notice_insert_action.ad]");
			service_notice.notice_insert_action(req, res);
			viewPage = "manager/notice/notice_insert_action.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 공지사항 수정
		else if(url.equals("/notice_update.ad")) {
			System.out.println("[url ==> /notice_update.ad]");
			viewPage = "manager/notice/notice_update.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 공지사항 UPDATE
		else if(url.equals("/notice_update_action.ad")) {
			System.out.println("[url ==> /notice_update_action.ad]");
			service_notice.notice_udpate_action(req, res);
			viewPage = "manager/notice/notice_update_action.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 공지사항 DELETE
		else if(url.equals("/notice_delete.ad")) {
			System.out.println("[url ==> /notice_delete.ad]");
			service_notice.notice_delete_action(req, res);
			viewPage = "manager/notice/notice_list.jsp";
			res.sendRedirect(viewPage);
		}
		/* ---------------------------- [board] ---------------------------- */
		// 문의사항 목록 READ
		else if(url.equals("/board_list.ad")) {
			System.out.println("[url ==> board_list.ad]");
			service.boardList(req, res);
			viewPage = "manager/csCenter/board_list.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 문의사항 상세 READ
		else if(url.equals("/board_read.ad")) {
			System.out.println("[url ==> board_read.ad]");
			service.boardDetail(req, res);
			viewPage = "manager/csCenter/board_read.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 문의사항 글쓰기 화면
		else if(url.equals("/board_add.ad")) {
			System.out.println("[url ==> board_add.ad]");
			viewPage = "manager/csCenter/board_add.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 문의사항 글 등록 INSERT
		else if(url.equals("/board_insert.ad")) {
			System.out.println("[url ==> board_insert.ad]");
			service.boardInsert(req, res);
			int num = (Integer)req.getAttribute("num");
			viewPage = req.getContextPath()+"/board_read.ad?num="+num;
			res.sendRedirect(viewPage);
		}
		// 문의사항 수정 화면
		else if(url.equals("/board_edit.ad")) {
			System.out.println("[url ==> board_edit.ad]");
			viewPage = "manager/csCenter/board_edit.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 문의사항 수정 UPDATE
		else if(url.equals("/board_update.ad")) {
			System.out.println("[url ==> board_update.ad]");
//			service.
			viewPage = "manager/csCenter/board_update.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		// 문의사항 삭제 DELETE
		else if(url.equals("/board_delete.ad")) {
			System.out.println("[url ==> board_delete.ad]");
			// 서비스 - 딜리트 동작시 겟파라미터 > num 값 > 해당 번호 글 삭제
			// 서비스 - if List에서 삭제 동작하면 num 값이 여러개니까 해당 글 모두 삭제할 수 있도록 동작
//			service.
			viewPage = "manager/csCenter/board_list.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [comment] ---------------------------- */
		// 댓글 작성
		else if(url.equals("/comment_add.ad")) {
			System.out.println("[url ==> /comment_add.ad]");
			service.commentAdd(req, res); /*$.ajax()의 콜백함수(success)로 넘어감*/
			getDispatcherForward(req, res, viewPage);
		}
		//댓글 목록
		else if(url.equals("/comment_list.ad")) {
			System.out.println("[url ==> /comment_list.ad]");
			service.commentList(req, res); /*$.ajax()의 콜백함수(success)로 넘어감*/
			viewPage = "manager/csCenter/comment_list.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [logout] ---------------------------- */
		else if(url.equals("/logout.ad")) {
			System.out.println("[url ==> logout.ad]");
			req.getSession().invalidate();
			viewPage = "index.jsp";
			getDispatcherForward(req, res, viewPage);
		}
	}

}

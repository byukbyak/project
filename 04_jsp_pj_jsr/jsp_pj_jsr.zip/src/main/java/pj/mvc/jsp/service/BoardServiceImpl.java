package pj.mvc.jsp.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import page.Paging;
import pj.mvc.jsp.dao.BoardDAO;
import pj.mvc.jsp.dao.BoardDAOImpl;
import pj.mvc.jsp.dto.BoardCommentDTO;
import pj.mvc.jsp.dto.BoardDTO;

public class BoardServiceImpl implements BoardService{

	// 게시글 목록
	@Override
	public void boardList(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		System.out.println("서비스 - boardList");

		// 3단계. 화면으로부터 입력받은 값을 받는다.
		// 해당 페이지 번호 클릭시
		String pageNum = req.getParameter("pageNum");

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5-1단계. 페이지 처리
		Paging paging = new Paging(pageNum);

		// 전체 게시글 개수
		int total = dao.boardCount();

		System.out.println("total : " + total);
		paging.setTotalCount(total);

		// 1을 클릭하면 1 10, 2를 클릭하면 11 20
		int start = paging.getStartRow();
		int end = paging.getEndRow();

		// 5-2단계. 게시글 목록
		List<BoardDTO> list = dao.boardList(start, end);
		//System.out.println("list : " + list);

		// 6단계. jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		req.setAttribute("list", list);
		req.setAttribute("paging", paging);
	}

	// 게시글 상세페이지
	@Override
	public void boardDetail(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
	System.out.println("서비스 - boardDetail()");
		// 3단계. 화면으로부터 입력받은 값 받기
		int num = Integer.parseInt(req.getParameter("num"));

		// 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5단계. 조회수 증가처리 및 게시글 상세 받아오기
		dao.plusReadCnt(num);
		BoardDTO dto = dao.getBoardDetail(num);

		// 글내용에 줄바꿈이 있는경우 HTML에서도 줄바꿈 되도록 설정
		String content = dto.getContent();
		if(content != null) {
			content = content.replace("\n", "<br>");
		}
		dto.setContent(content);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("board", dto);
	}

	// 게시글 작성처리 페이지
	@Override
	public void boardInsert(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - boardInsert()");

		// 3단계. 화면으로부터 입력받은 값을 받아 DTO에 담기
		BoardDTO dto = new BoardDTO();
		dto.setWriter(req.getParameter("writer"));
		dto.setPassword(req.getParameter("password"));
		dto.setTitle(req.getParameter("title"));
		dto.setContent(req.getParameter("content"));
		dto.setCategory(req.getParameter("category"));

		// 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5단계. 인서트
		int insertCnt = dao.boardInsert(dto);
		System.out.println("서비스 insertCnt :"+insertCnt);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("insertCnt", insertCnt);
		req.setAttribute("num", dto.getNum());
	}

	// 게시글 비밀번호 체크
	@Override
	public void password_chk(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - password_chk()");

		// 3단계. 화면으로부터 입력받은 값(비밀번호), hidden값(num)을 받아 DTO에 담기
		int num = Integer.parseInt(req.getParameter("num"));
		String password = req.getParameter("password");

		System.out.println("글 번호 : " + num);
		System.out.println("글 비밀번호 : " + password);

		// 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5단계. 비밀번호 체크
		String resultPassword = dao.password_chk(num, password);
		System.out.println("비밀번호 체크 결과 : "+resultPassword);

		// 비밀번호 동일 여부에 따라 다른 페이지로 이동시키기 위한 변수 생성
		String viewPage="";

		// 비밀번호 체크 결과로 받은 비밀번호가 있으면 수정화면으로 이동
		if(resultPassword != null) {
			BoardDTO dto = dao.getBoardDetail(num);
			req.setAttribute("board", dto);
		viewPage = "manager/csCenter/board_edit.jsp?password_error=y";

		// 예외 발생시 메서드에 throws ServletException, IOException 추가
			RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
			dispatcher.forward(req, res);

		} else { // 비밀번호가 틀리면 게시글 상세화면으로 이동
		viewPage = req.getContextPath()+"/board_detailAction.ad?num="+num+"&message=error";
			res.sendRedirect(viewPage);
		}

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("password", password);
	}

	@Override // 게시글 수정처리 페이지
	public void boardUpdate(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("서비스 - boardUpdate()");

		// 3단계. 화면으로부터 입력받은 값 받기
		int num = Integer.parseInt(req.getParameter("num"));
		String writer = req.getParameter("writer");
		String password = req.getParameter("password");
		String title = req.getParameter("title");
		String content = req.getParameter("content");

		BoardDTO dto = new BoardDTO();
		dto.setNum(num);
		dto.setWriter(writer);
		dto.setPassword(password);
		dto.setTitle(title);
		dto.setContent(content);

		// 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5단계. 게시글 등록처리
		int updateResult = dao.boardUpdate(dto);

		// 6단계. jsp로 처리 결과 전달
		req.setAttribute("updateResult", updateResult);
	}

	@Override // 게시글 삭제처리 페이지
	public void boardDelete(HttpServletRequest req, HttpServletResponse res) {
		System.out.println("서비스 - boardDelete()");

		// 3단계. 화면으로부터 입력받은 값 받기
		int num = Integer.parseInt(req.getParameter("num"));
		System.out.println("삭제할 게시글 번호 : " + num);

		// 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5단계. 게시글 삭제
		dao.boardDelete(num);

	}

	@Override // 댓글추가
	public void commentAdd(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		System.out.println("서비스 - commentAdd()");

		// 3단계. 화면으로부터 입력받은 hidden값(num) 받고 댓글DTO에 담기
		BoardCommentDTO dto = new BoardCommentDTO();

		dto.setBoard_num(Integer.parseInt(req.getParameter("board_num")));
		dto.setWriter(req.getParameter("writer"));
		dto.setContent(req.getParameter("content"));

		// 4단계. 싱글톤 방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();

		// 5단계. 댓글 insert
		dao.commentInsert(dto);

		//실행 끝나면 board_detailAction.jsp의 comment_add() 콜백함수(success) 로 넘어감
	}

	// 댓글 목록처리 페이지
	@Override
	public void commentList(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException {

		System.out.println("req.getParameter('num'): " + req.getParameter("num"));
		System.out.println("서비스 - commentList");

		// 3단계. 화면으로부터 입력받은 값(num)를 받는다.
		int num = Integer.parseInt(req.getParameter("num"));

		System.out.println("num: " + num);

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		BoardDAO dao = BoardDAOImpl.getInstance();
		List<BoardCommentDTO> list = dao.getCommentList(num);

		// 5단계. select
		req.setAttribute("list", list); // >> comment_list()의 콜백함수로 result 전달
	}

}
package pj.mvc.jsp.dto;

public class CartDTO {

	private int cart_num;//PK
	private String p_name;//FK
	private String p_img;//FK
	private int p_price;//FK
	private int cart_qty;
	private int total_amount;

	public int getCart_num() {
		return cart_num;
	}
	public void setCart_num(int cart_num) {
		this.cart_num = cart_num;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_img() {
		return p_img;
	}
	public void setP_img(String p_img) {
		this.p_img = p_img;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public int getCart_qty() {
		return cart_qty;
	}
	public void setCart_qty(int cart_qty) {
		this.cart_qty = cart_qty;
	}
	public int getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	@Override
	public String toString() {
		return "[CartDTO 정보]"
				+ "\n 장바구니 번호 : "+cart_num
				+ "\n 상품명 : "+p_name
				+ "\n 이미지파일명 : "+p_img
				+ "\n 가격 : "+p_price
				+ "\n 수량 : "+cart_qty
				+ "\n 합계 : "+total_amount;
	}

}
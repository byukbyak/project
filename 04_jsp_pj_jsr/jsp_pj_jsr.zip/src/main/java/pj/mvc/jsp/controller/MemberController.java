package pj.mvc.jsp.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("*.me")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MemberController() {
        super();
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		action(req, res);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		doGet(req, res);
	}
	
	public void getDispatcherForward(HttpServletRequest req, HttpServletResponse res, String viewPage)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = req.getRequestDispatcher(viewPage);
		dispatcher.forward(req, res);
	}
	
	public void action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		
		req.setCharacterEncoding("UTF-8");
		res.setContentType("text/html;charset=utf-8");
		String viewPage = "";
		
		String uri = req.getRequestURI(); // request받은 URI를 받을 변수 선언
		String contextPath = req.getContextPath();
		String url = uri.substring(contextPath.length());
		
		/* ---------------------------- [mypage] ---------------------------- */
		// 마이페이지 메인화면
		if(url.equals("/*.me") || url.equals("/mypage.me")) {
			System.out.println("[url : mypage.me]");
			viewPage = "customer/mypage/mypage.jsp";
			getDispatcherForward(req, res, viewPage);
		}
		/* ---------------------------- [mypage] ---------------------------- */
		// 마이페이지 - 메인화면
		else if(url.equals("/root.me")) {
			System.out.println("[url : root.me]");
			viewPage = "customer/mypage/폴더명/root.jsp";
			getDispatcherForward(req, res, viewPage);
		}
	}

}

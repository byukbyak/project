package pj.mvc.jsp.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ProductService {
	
	public void productListAction(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;
	public void productReadAction(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;
	public void productAddAction(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;
	public void productUpdateAction(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;
	public void productDeleteAction(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException;

}

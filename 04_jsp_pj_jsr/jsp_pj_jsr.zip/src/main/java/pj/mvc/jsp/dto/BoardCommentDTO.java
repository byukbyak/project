package pj.mvc.jsp.dto;

import java.sql.Date;

public class BoardCommentDTO {
	
	private int comment_num; 		// PK, 댓글 일련번호
	private int board_num;			// Foreign key, 게시글 번호
	private String writer;			// 작성자
	private String content;			// 글내용
	private Date reg_date;			// 작성일
	
	public int getComment_num() {
		return comment_num;
	}
	public void setComment_num(int comment_num) {
		this.comment_num = comment_num;
	}
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}

	@Override
	public String toString() {
		return "[BoardCommentDTO 정보]"
				+ "COMMENT_NUM : " + comment_num + "\n"
				+ "board_num : " + board_num + "\n"
				+ "writer : " + writer + "\n"
				+ "content : " + content + "\n"
				+ "reg_date : " + reg_date;
	}
	
}
/*	[mvc_board_comment_tbl 테이블 정보]
	COMMENT_NUM NOT NULL NUMBER(7)    
	BOARD_NUM   NOT NULL NUMBER(7)    
	WRITER      NOT NULL VARCHAR2(50) 
	CONTENT     NOT NULL CLOB         
	REG_DATE             DATE */
package pj.mvc.jsp.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import page.Paging;
import pj.mvc.jsp.dao.NoticeDAO;
import pj.mvc.jsp.dao.NoticeDAOImpl;
import pj.mvc.jsp.dto.NoticeDTO;

public class NoticeServiceImpl implements NoticeService {

	@Override // 게시글 목록
	public void notice_list_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_list_action");

		// 3단계. 화면으로부터 입력받은 값을 받는다.
		// 해당 페이지 번호 클릭시
		String pageNum = req.getParameter("pageNum");

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		NoticeDAO dao = NoticeDAOImpl.getInstance();

		// 5단계. 기능동작
		// 5-1. 페이지 처리
		Paging paging = new Paging(pageNum);

		// 전체 게시글 개수
		int total = dao.noticeCnt();
		System.out.println("total : " + total);
		paging.setTotalCount(total);

		// 1을 클릭하면 1 10, 2를 클릭하면 11 20
		int start = paging.getStartRow();
		int end = paging.getEndRow();

		// 5-2. 게시글 목록
		List<NoticeDTO> list = dao.notice_list(start, end);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("list", list);
		req.setAttribute("paging", paging);

	}

	@Override // 게시글 상세
	public void notice_read_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_read_action");

		// 3단계. 화면으로부터 입력받은 값을 받는다.
		int num = Integer.parseInt(req.getParameter("num"));

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		NoticeDAO dao = NoticeDAOImpl.getInstance();

		// 5단계. 기능동작
		dao.plusReadCnt(num);
		NoticeDTO dto = dao.notice_read(num);

		// 글내용에 줄바꿈이 있는경우 HTML에서도 줄바꿈 되도록 설정
		String content = dto.getContent();
		if(content != null) {
			content = content.replace("\n", "<br>");
		}
		dto.setContent(content);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("dto", dto);

	}

	@Override // 게시글 INSERT
	public void notice_insert_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_insert_action");

		// 3단계. 화면으로부터 입력받은 값을 받는다.
		NoticeDTO dto = new NoticeDTO();
		dto.setTitle(req.getParameter("title"));
		dto.setContent(req.getParameter("content"));
		dto.setWriter(req.getParameter("writer"));

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		NoticeDAO dao = NoticeDAOImpl.getInstance();

		// 5단계. 기능동작
		int cnt = dao.notice_insert(dto);
		System.out.println("INSERT(성공:1,실패:0) : " + cnt);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("cnt", cnt);
		req.setAttribute("num", dto.getNum());

	}

	@Override // 게시글 UPDATE
	public void notice_udpate_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_udpate_action");

		// 3단계. 화면으로부터 입력받은 값을 받는다.
		NoticeDTO dto = new NoticeDTO();
		dto.setNum(Integer.parseInt(req.getParameter("num")));
		dto.setTitle(req.getParameter("title"));
		dto.setContent(req.getParameter("content"));
		dto.setWriter(req.getParameter("writer"));

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		NoticeDAO dao = NoticeDAOImpl.getInstance();

		// 5단계. 기능동작
		int cnt = dao.notice_update(dto);
		System.out.println("UPDATE(성공:1,실패:0) : " + cnt);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("cnt", cnt);
	}

	@Override // 게시글 DELETE
	public void notice_delete_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_delete_action");

		// 3단계. 화면으로부터 입력받은 값을 받는다.
		int num = Integer.parseInt(req.getParameter("num"));

		// 4단계. 싱글톤방식으로 dao 객체 생성, 다형성 적용
		NoticeDAO dao = NoticeDAOImpl.getInstance();

		// 5단계. 기능동작
		int cnt = dao.notice_delete(num);
		System.out.println("DELETE(성공:1,실패:0) : " + cnt);

		// 6단계. jsp로 처리 결과 전달(request 또는 session으로)
		req.setAttribute("cnt", cnt);
	}

}

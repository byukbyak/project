package pj.mvc.jsp.dto;

import java.sql.Date;

public class ProductDTO {

	private int p_code;
	private String p_brand;
	private String p_category;
	private String p_name;
	private String p_content;
	private String p_img;
	private int p_price;
	private int p_qty;
	private String p_option;
	private Date indate; /* java.sql */
	private Date outdate; /* java.sql */
	private String status;
	
	public ProductDTO() {}
	
	public String getP_option() {
		return p_option;
	}
	public void setP_option(String p_option) {
		this.p_option = p_option;
	}
	public int getP_code() {
		return p_code;
	}
	public void setP_code(int p_code) {
		this.p_code = p_code;
	}
	public String getP_brand() {
		return p_brand;
	}
	public void setP_brand(String p_brand) {
		this.p_brand = p_brand;
	}
	public String getP_category() {
		return p_category;
	}
	public void setP_category(String p_category) {
		this.p_category = p_category;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_content() {
		return p_content;
	}
	public void setP_content(String p_content) {
		this.p_content = p_content;
	}
	public String getP_img() {
		return p_img;
	}
	public void setP_img(String p_img) {
		this.p_img = p_img;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public int getP_qty() {
		return p_qty;
	}
	public void setP_qty(int p_qty) {
		this.p_qty = p_qty;
	}
	public Date getIndate() {
		return indate;
	}
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	public Date getOutdate() {
		return outdate;
	}
	public void setOutdate(Date outdate) {
		this.outdate = outdate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "[ProductDTO 정보]"
				+ "\n 상품코드 : " + p_code
				+ "\n 브랜드 : " + p_brand
				+ "\n 카테고리 : " + p_category
				+ "\n 상품명 : " + p_name
				+ "\n 상품설명 : " + p_content
				+ "\n 이미지 : " + p_img
				+ "\n 판매가격 : " + p_price
				+ "\n 재고수량 : " + p_qty
				+ "\n 상품옵션 : " + p_option
				+ "\n 등록일 : " + indate
				+ "\n 판매기한 : " + outdate
				+ "\n 판매상태 : " + status + "\n";
	}
	
}
/*
	CREATE TABLE mvc_product_tbl (
    p_code      NUMBER(6)       PRIMARY KEY,                        -- 재고번호,시퀀스
    p_brand     VARCHAR2(20)    NOT NULL,                           -- 브랜드명
    p_category  VARCHAR2(20)    NOT NULL,                           -- 제품 카테고리
    p_name      VARCHAR2(20)    NOT NULL,                           -- 제품명
    p_content   VARCHAR2(100)   NOT NULL,                           -- 제품설명
    p_img       VARCHAR2(50)    NOT NULL,                           -- 이미지명
    p_price     NUMBER(7)       NOT NULL,                           -- 판매가격
    p_qty       NUMBER(6)       NOT NULL,                           -- 재고수량
    p_option    VARCHAR2(20)    DEFAULT '선택안함',                   -- 상품옵션 (각각다름)
    indate      DATE            DEFAULT sysdate,                    -- 등록일,자동생성
    outdate     DATE            DEFAULT sysdate+(INTERVAL '1' YEAR),-- 판매기한,자동생성
    status      VARCHAR2(15)    DEFAULT '준비중'                     -- 판매상태(준비중,판매중,판매중지,판매완료,예약중)
);
*/
package pj.mvc.jsp.dto;

import java.sql.Timestamp;
import java.sql.Date;

public class CustomerDTO {

	// 멤버변수 = 컬럼명 = input 태그명
	private String id;
	private String password;
	private String name;
	private String nickname;
	private Date birthday; // import java.sql.Date;
	private String address;
	private String hp;
	private String email;
	private Timestamp regDate; // import java.sql.Timestamp;
	private String show;
	
	// 디폴트 생성자
	public CustomerDTO() {}
	
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Timestamp getRegDate() {
		return regDate;
	}
	public void setRegDate(Timestamp regDate) {
		this.regDate = regDate;
	}
	
	@Override
	public String toString() {
		return "[CustomerDTO 클래스 정보]"
				+ "\n ID : " + getId()
				+ "\n PW : " + getPassword()
				+ "\n NAME : " + getName()
				+ "\n NAME : " + getName()
				+ "\n BIRTHDAY : " + getBirthday()
				+ "\n ADDRESS : " + getAddress()
				+ "\n HP : " + getHp()
				+ "\n EMAIL : " + getEmail()
				+ "\n REGDATE : " + getRegDate() + "\n";
	}
	
	/*
	 	[테이블정보]
		CREATE TABLE mvc_customer_tbl (
	    id          VARCHAR2(20) PRIMARY KEY,
	    password    VARCHAR2(20)    NOT NULL,
	    name        VARCHAR2(20)    NOT NULL,
	    nickname    VARCHAR2(20)    NOT NULL,
	    birthday    DATE            NOT NULL,
	    address     VARCHAR2(50)    NOT NULL,
	    hp          VARCHAR2(13)    NOT NULL,
	    email       VARCHAR2(50)    NOT NULL,
	    regDate     TIMESTAMP DEFAULT sysdate,
	    show CHAR(1) DEFAULT 'y'
);
	*/
}

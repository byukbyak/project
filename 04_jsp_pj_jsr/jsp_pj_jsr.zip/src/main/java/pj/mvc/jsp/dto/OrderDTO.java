package pj.mvc.jsp.dto;

public class OrderDTO {

	private int order_num;//PK
	private int p_code;//FK
	private String p_name;
	private String p_img;
	private int p_price;
	private int cart_qty;
	private int total_amount;

	public int getOrder_num() {
		return order_num;
	}
	public void setOrder_num(int order_num) {
		this.order_num = order_num;
	}
	public int getP_code() {
		return p_code;
	}
	public void setP_code(int p_code) {
		this.p_code = p_code;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_img() {
		return p_img;
	}
	public void setP_img(String p_img) {
		this.p_img = p_img;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public int getCart_qty() {
		return cart_qty;
	}
	public void setCart_qty(int cart_qty) {
		this.cart_qty = cart_qty;
	}
	public int getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	@Override
	public String toString() {
		return "[OrderDTO 정보]"
		+ "\n 주문번호 : "+order_num
		+ "\n 상품코드 : "+p_code
		+ "\n 상품명 : "+p_name
		+ "\n 이미지파일명 : "+p_img
		+ "\n 가격 : "+p_price
		+ "\n 수량 : "+cart_qty
		+ "\n 합계 : "+total_amount;
	}

}
package pj.mvc.jsp.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface NoticeService {
	
	// 게시글 목록
	public void notice_list_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException;
	
	// 게시글 상세
	public void notice_read_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException;
	
	// 게시글 INSERT
	public void notice_insert_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException;
	
	// 게시글 UPDATE
	public void notice_udpate_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException;
	
	// 게시글 DELETE
	public void notice_delete_action(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException;
	
}

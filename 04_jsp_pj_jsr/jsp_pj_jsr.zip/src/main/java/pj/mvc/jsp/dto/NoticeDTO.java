package pj.mvc.jsp.dto;

import java.sql.Date;

public class NoticeDTO {

	public int num;
	public String title;
	public String content;
	public String writer;
	public int readCnt;
	public Date indate;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public int getReadCnt() {
		return readCnt;
	}
	public void setReadCnt(int readCnt) {
		this.readCnt = readCnt;
	}
	public Date getIndate() {
		return indate;
	}
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	@Override
	public String toString() {
		return "[NoticeDTO - 정보]"
				+ "\n num : "+num
				+ "\n title : "+title
				+ "\n content : "+content
				+ "\n writer : "+writer
				+ "\n readCnt : "+readCnt
				+ "\n indate : "+indate;
	}
}

/*
	CREATE TABLE mvc_notice_tbl (
	    num NUMBER PRIMARY KEY,
	    title VARCHAR(50) NOT NULL,
	    content CLOB,
	    writer VARCHAR(20) NOT NULL,
	    readCnt NUMBER DEFAULT 0,
	    indate DATE DEFAULT sysdate
	);
*/
package pj.mvc.jsp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import pj.mvc.jsp.dto.CustomerDTO;

public class CustomerDAOImpl implements CustomerDAO {

	// 커넥션 풀 객체를 보관
	DataSource dataSource;
	
	Connection conn = null; // 오라클 연결
	PreparedStatement pstmt = null; // SQL 문장
	ResultSet rs = null; // 결과
	
	// 싱글톤 방식 : 객체를 1번만 생성
	static CustomerDAOImpl instance = new CustomerDAOImpl();
	public static CustomerDAOImpl getInstance() {
		if(instance == null) {
			instance = new CustomerDAOImpl();
		}
		return instance;
	}
	
	// 생성자
	private CustomerDAOImpl() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/jsp_pj_jsr");
			
		} catch (NamingException e) {
			e.printStackTrace();
		}
	};
	
	// 중복확인 처리
	@Override
	public int idCheck(String strId) {
		System.out.println("dao - ID 중복확인 처리");
		int selectCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT * FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				selectCnt = 1;
			}
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	
	// 회원가입 처리
	@Override
	public int insertCustomer(CustomerDTO dto) {
		System.out.println("dao - 회원가입처리");
		int insertCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "INSERT INTO mvc_customer_tbl(id, password, name, birthday, address, hp, email, nickname) VALUES(?,?,?,?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getId());
			pstmt.setString(2, dto.getPassword());
			pstmt.setString(3, dto.getName());
			pstmt.setDate(4, dto.getBirthday());
			pstmt.setString(5, dto.getAddress());
			pstmt.setString(6, dto.getHp());
			pstmt.setString(7, dto.getEmail());
			pstmt.setString(8, dto.getNickname());

			insertCnt = pstmt.executeUpdate(); // 입력성공:1 입력실패:0
			System.out.println("insertCnt : "+insertCnt);
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return insertCnt;
	}
	// 로그인 처리 / 회원정보 인증(수정, 탈퇴)
	@Override
	public int idPasswordChk(String strId, String strPassword) {
		System.out.println("dao - 로그인 처리, 회원정보 인증(수정, 탈퇴)");
		int selectCnt = 0;
		
		try {
			
			conn = dataSource.getConnection();
			String sql = "SELECT id, password FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);;
			
			rs = pstmt.executeQuery();
			
			// 로그인한 id와 일치하고
			if(rs.next()) {
				if(strPassword.equals(rs.getString("password"))) {
					selectCnt = 1;
				} else {
					selectCnt = -1;
				}
			}
			
			// id 불일치 => 비가입 selcetCnt = 0
			else {
				selectCnt = 0;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return selectCnt;
	}
	// 회원정보 인증 및 탈퇴처리
	@Override
	public int deleteCustomer(String strId) {
		System.out.println("dao - 회원정보 인증 및 탈퇴처리");
		int deleteCnt = 0;
		
		try {
			conn = dataSource.getConnection();
			String sql = "DELETE FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			deleteCnt = pstmt.executeUpdate();
			System.out.println("dao deleteCnt : "+deleteCnt);
			
		} catch (SQLException e) {
			e.getStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.getStackTrace();
			}
		}
		return deleteCnt;
	}
	// 회원정보 인증 및 상세페이지
	@Override
	public CustomerDTO getCustomerDetail(String strId) {
		System.out.println("dao - 회원정보 인증 및 상세페이지");
		
		// 1. 바구니 생성
		CustomerDTO dto = new CustomerDTO();
		
		try {
			conn = dataSource.getConnection();
			
			// 2. srtId(로그인 화면에서 입력받은 세션id)와 일치하는 데이터가 있는지 조회
			String sql = "SELECT * FROM mvc_customer_tbl WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			
			rs = pstmt.executeQuery();
			
			// 3. ResultSet에 id와 일치하는 한사람의 회원정보가 존재하면
			if(rs.next()) {
				// ResultSet을 읽어서 DTO에 setter로 담아주기
				dto.setId(rs.getString("id"));
				dto.setPassword(rs.getString("password"));
				dto.setName(rs.getString("name"));
				dto.setHp(rs.getString("hp"));
				dto.setEmail(rs.getString("email"));
				dto.setBirthday(rs.getDate("birthday"));
				dto.setAddress(rs.getString("address"));
				dto.setRegDate(rs.getTimestamp("regdate"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return dto;
	}
	// 회원정보 수정 처리
	@Override
	public int updateCustomer(CustomerDTO dto) {
		System.out.println("dao - 회원정보 수정 처리");
		
		int updateCnt = 0;
				
		try {
			
			conn = dataSource.getConnection();
			String sql = "UPDATE mvc_customer_tbl SET password=?, name=?, birthday=?, address=?, hp=?, email=? WHERE id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, dto.getPassword());
			pstmt.setString(2, dto.getName());
			pstmt.setDate(3, dto.getBirthday());
			pstmt.setString(4, dto.getAddress());
			pstmt.setString(5, dto.getHp());
			pstmt.setString(6, dto.getEmail());
			pstmt.setString(7, dto.getId());
			
			updateCnt = pstmt.executeUpdate();
//			System.out.println("dto.getPassword() : "+dto.getPassword());
//			System.out.println("dto.getName() : "+dto.getName());
//			System.out.println("dto.getBirthday() : "+dto.getBirthday());
//			System.out.println("dto.getAddress() : "+dto.getAddress());
//			System.out.println("dto.getHp() : "+dto.getHp());
//			System.out.println("dto.getEmail() : "+dto.getEmail());
//			System.out.println("dto.getId() : "+dto.getId());
			
			System.out.println("updateCnt : "+updateCnt);
				
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return updateCnt;
	}

	@Override
	public String toString() {
		return "[CustomerDAOImpl 클래스정보]";
	}

	@Override
	public String getNickName(String strId) {
		System.out.println("DAO - getNickName");
		String nickname = null;
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT nickname FROM mvc_customer_tbl WHERE id=? ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, strId);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				nickname = rs.getString("nickname");
			} else {
				System.out.println("DAO - getNickName SELECT 실패");
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs != null) rs.close();
				if(pstmt != null) pstmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return nickname;
	}
	
}

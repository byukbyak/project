package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;

import com.spring.pj_jsr.dto.NoticeDTO;

public interface NoticeDAO {

	// 1. 게시글 개수
	public int noticeCnt();

	// 2. 조회수 증가
	int plusReadCnt(int num);

	// 3. 공지사항 목록 - 관리자
	List<NoticeDTO> notice_list_admin(Map<String, Object> map);

	// 4. 공지사항 목록 - 고객
	List<NoticeDTO> notice_list(Map<String, Object> map);

	// 5. 게시글 상세
	NoticeDTO notice_read(int num);

	// 6. 공지사항 INSERT
	int notice_insert(NoticeDTO dto);

	// 7. 공지사항 UPDATE
	int notice_update(NoticeDTO dto);

	// 8. 공지사항 DELETE
	int notice_delete(int num);

}

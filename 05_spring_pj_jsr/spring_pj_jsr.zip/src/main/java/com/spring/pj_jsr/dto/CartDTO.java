package com.spring.pj_jsr.dto;

public class CartDTO {

	private int c_num; // PK - 장바구니 번호
	private String id; // FK - 고객 아이디
	private int p_code; // FK - 상품 번호
	private String p_name; // 상품명
	private String p_brand; // 브랜드명
	private String p_category; // 상품 카테고리
	private String nickname; // 고객 닉네임
	private String p_img; // 상품 이미지명
	private int p_price; // 상품 가격
	private int c_qty; // 장바구니 번호 별 장바구니에 담은 수량
	private int c_total; // 장바구니 번호 별 합계

	public CartDTO() {}

	public String getP_category() {
		return p_category;
	}
	public void setP_category(String p_category) {
		this.p_category = p_category;
	}
	public String getP_brand() {
		return p_brand;
	}
	public void setP_brand(String p_brand) {
		this.p_brand = p_brand;
	}
	public int getC_total() {
		return c_total;
	}
	public void setC_total(int c_total) {
		this.c_total = c_total;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public int getC_num() {
		return c_num;
	}
	public void setC_num(int c_num) {
		this.c_num = c_num;
	}
	public int getP_code() {
		return p_code;
	}
	public void setP_code(int p_code) {
		this.p_code = p_code;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getC_qty() {
		return c_qty;
	}
	public void setC_qty(int c_qty) {
		this.c_qty = c_qty;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_img() {
		return p_img;
	}
	public void setP_img(String p_img) {
		this.p_img = p_img;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}

	@Override
	public String toString() {
		return "\n[CartDTO 정보]"
				+ "\n 장바구니 번호 : "+c_num
				+ "\n 아이디 : "+id
				+ "\n 상품코드 : "+p_code
				+ "\n 상품명 : "+p_name
				+ "\n 브랜드 : "+p_brand
				+ "\n 카테고리 : "+p_category
				+ "\n 이미지파일명 : "+p_img
				+ "\n 가격 : "+p_price
				+ "\n 수량 : "+c_qty
				+ "\n 주문별합계 : "+c_total;
	}
}

/*
	CREATE TABLE cart_tbl (
	    cart_no NUMBER CONSTRAINT cart_no_pk Primary key,
	    p_code NUMBER NOT NULL CONSTRAINT cart_p_code_fk REFERENCES product_tbl(p_code) ON DELETE CASCADE,
	    id VARCHAR2(20) NOT NULL CONSTRAINT cart_id_fk REFERENCES customer_tbl(id) ON DELETE CASCADE,
	    c_qty NUMBER NOT NULL
	);
*/

/*
	CREATE OR REPLACE VIEW v_cart AS
	SELECT c.cart_no as c_num,
       c.id as id,
       c.p_code as p_code,
       p.p_name as p_name,
       p.p_brand as p_brand,
       p.p_category as p_category,
       p.p_img as p_img,
       p.p_price as p_price,
       m.nickname as nickname,
       c.c_qty as c_qty,
       (p.p_price*c.c_qty) as c_total
	FROM customer_tbl m,
    product_tbl p,
    cart_tbl c
	WHERE c.p_code = p.p_code
	AND m.id = c.id;

*/
package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.pj_jsr.dto.NoticeDTO;

@Repository
public class NoticeDAOImpl implements NoticeDAO {

	@Autowired
	SqlSession sqlSession;

	@Override // 1. 게시글 개수
	public int noticeCnt() {
		System.out.println("DAO - noticeCnt");
		return sqlSession.getMapper(NoticeDAO.class).noticeCnt();
	}

	@Override // 2. 조회수 증가
	public int plusReadCnt(int notice_no) {
		System.out.println("DAO - plusReadCnt");
		return sqlSession.getMapper(NoticeDAO.class).plusReadCnt(notice_no);
	}

	@Override // 3. 게시글 목록 - 관리자 / 글을 삭제할 경우 공개, 비공개가 보여야함
	public List<NoticeDTO> notice_list_admin(Map<String, Object> map) {
		System.out.println("DAO - notice_list");
		return sqlSession.getMapper(NoticeDAO.class).notice_list_admin(map);
	}

	@Override // 4. 게시글 목록 - 고객
	public List<NoticeDTO> notice_list(Map<String, Object> map) {
		System.out.println("DAO - notice_list");
		return sqlSession.getMapper(NoticeDAO.class).notice_list(map);
	}

	@Override // 5. 게시글 상세
	public NoticeDTO notice_read(int notice_no) {
		System.out.println("DAO - notice_read");
		return sqlSession.getMapper(NoticeDAO.class).notice_read(notice_no);
	}

	@Override // 6. 공지사항 INSERT
	public int notice_insert(NoticeDTO dto) {
		System.out.println("DAO - notice_insert");
		return sqlSession.getMapper(NoticeDAO.class).notice_insert(dto);
	}

	@Override // 7. 공지사항 UPDATE
	public int notice_update(NoticeDTO dto) {
		System.out.println("DAO - notice_update");
		return sqlSession.getMapper(NoticeDAO.class).notice_update(dto);
	}

	@Override // 8. 공지사항 DELETE > 고객한테는 안보이지만, 관리자한테는 공개, 비공개가 보여야함
	public int notice_delete(int notice_no) {
		System.out.println("DAO - notice_delete");
		return sqlSession.getMapper(NoticeDAO.class).notice_delete(notice_no);
	}

}

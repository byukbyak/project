package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;

import com.spring.pj_jsr.dto.CartDTO;
import com.spring.pj_jsr.dto.OrderDTO;
import com.spring.pj_jsr.dto.SalesDTO;

public interface OrderDAO {

	/* -------------------- [ 장바구니 ] -------------------- */

	// 1. 장바구니 목록 불러오기
	public List<CartDTO> cart_read(String strId);

	// 2. 장바구니 담기
	public int cart_add(Map<String, Object> map);

	// 3. 장바구니 개별 삭제(단수)
	int deleteCartItem(int c_num);

	// 3. 장바구니 개별 삭제(배열)
	int deleteCartItemArr(String[] c_num_arr);

	// 4. 장바구니 비우기
	int deleteCartAll();

	// 5. 장바구니에서 선택한 목록
	List<CartDTO> selectPayList(String[] c_num_arr);

	// 6. 장바구니 수량변경
	int updateCartItemAmount(Map<String, Object> map);

	/* -------------------- [ 주문 ] -------------------- */

	// 7. 전체 주문목록 조회 - 관리자
	List<OrderDTO> OrderList(Map<String, Object> map);

	// 8. 특정고객 주문조회
	List<OrderDTO> selectOrderList(Map<String, Object> map);

	// 9. 모든 구매 목록 조회
	List<OrderDTO> selectOrderStatuslist(Map<String, Object> map);

	// 10. 모든 환불 목록 조회
	List<OrderDTO> selectRefundStatuslist(Map<String, Object> map);

	// 11. 결제 후 주문 등록
	int insertOrder(List<OrderDTO> olist);

	// 12. 상태 변경
	int updateState(Map<String, Object> map);

	// 13. 전체 주문 총 개수
	int selectOrderAllTotal();

	// 14. 관리자 - 주문 총 개수
	int orderCount();

	// 15. 주문 총 개수
	int customerOrderCount(String customer_id);

	// 16. 고객 환불 총 개수
	int selectRefundTotal(String customer_id);

	// 17. 환불 총 개수
	int refundTotalCount();

	// 18. 바로구매 ORDER_TBL (1건) INSERT
	public int now_buy(OrderDTO dto);

	/* -------------------- [ 결산 ] -------------------- */

	// 19. 결산
	List<SalesDTO> totalOrderSales();

}

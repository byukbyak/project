package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.pj_jsr.dto.AdminDTO;
import com.spring.pj_jsr.dto.CustomerDTO;
import com.spring.pj_jsr.util.SettingValues;

@Repository
public class CustomerDAOImpl implements CustomerDAO {

	@Autowired
	SqlSession sqlSession;

	// 1. ID 중복확인 처리
	@Override
	public int idCheck(String strId) {
		System.out.println("dao - ID 중복확인 처리");
		return sqlSession.getMapper(CustomerDAO.class).idCheck(strId);
	}

	// 2. 회원가입 처리
	@Override
	public int insertCustomer(CustomerDTO dto) {
		System.out.println("dao - 회원가입처리");
		return sqlSession.getMapper(CustomerDAO.class).insertCustomer(dto);
	}
	// 3. 로그인 처리 / 회원정보 인증(수정, 탈퇴)
	@Override
	public int idPasswordChk(Map<String, Object> map) {
		System.out.println("dao - 로그인 처리, 회원정보 인증(수정, 탈퇴)");
		return sqlSession.getMapper(CustomerDAO.class).idPasswordChk(map);
	}
	// 4. 회원정보 인증 및 탈퇴처리
	@Override
	public int deleteCustomer(String strId) {
		System.out.println("dao - 회원정보 인증 및 탈퇴처리");
		return sqlSession.getMapper(CustomerDAO.class).deleteCustomer(strId);
	}
	// 5. 회원정보 인증 및 상세페이지
	@Override
	public CustomerDTO getCustomerDetail(String strId) {
		System.out.println("dao - 회원정보 인증 및 상세페이지");
		return sqlSession.getMapper(CustomerDAO.class).getCustomerDetail(strId);
	}

	// 6. 회원정보 수정 처리
	@Override
	public int updateCustomer(CustomerDTO dto) {
		System.out.println("dao - 회원정보 수정 처리");
		return sqlSession.getMapper(CustomerDAO.class).updateCustomer(dto);
	}

	@Override // 7-1. 관리자 정보 가져오기
	public AdminDTO getAdminInfo(String strId) {
		System.out.println("DAO - getAdminInfo");
		System.out.println("DAO - strId : "+ strId);
		AdminDTO dto = new AdminDTO();
		dto = sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.adminInfo", strId);
		return dto;
	}

	@Override // 7. 닉네임 가져오기
	public String getNickName(String strId) {
		System.out.println("DAO - getNickName");
		System.out.println("DAO - strId : "+ strId);

		String nickname = null;
		if(strId.equals("bb") || strId.equals("bbyak") || strId.equals("bbyuk")) {
			nickname = sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.adminNick", strId);
		} else {
			nickname = sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.customerNick", strId);
		}
		return nickname;
	}

	@Override // 8. 등급 가져오기
	public String getGrade(String strId) {
		System.out.println("DAO - getGrade");
		return sqlSession.getMapper(CustomerDAO.class).getGrade(strId);
	}

	@Override // 9. 관리자 아이디, 비밀번호 확인
	public int adminCheck(Map<String, Object> map) {
		System.out.println("DAO - adminCheck");
		// 로그인 확인 결과 [ 성공:99 실패:0]
		int loginResult = 0;
		loginResult = sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.adminCheck", map);
		if(loginResult == 1) loginResult = 99;
		return loginResult;
	}

	@Override // 10. 회원정보 DB 조회
	public CustomerDTO selectCustomer(String strId) {
		System.out.println("DAO - selectCustomer");
		return sqlSession.getMapper(CustomerDAO.class).selectCustomer(strId);
	}

	@Override // 11. 회원정보 전체 조회
	public List<CustomerDTO> selectCustomerList(Map<String, Object> map) {
		System.out.println("DAO - selectCustomerList");
		return sqlSession.getMapper(CustomerDAO.class).selectCustomerList(map);
	}

	@Override // 12. 전체 회원 수
	public int selectCustomerTotal() {
		System.out.println("DAO - selectCustomerTotal");
		return sqlSession.getMapper(CustomerDAO.class).selectCustomerTotal();
	}

	// 시큐리티 - 가입성공시 이메일인증을 위해 이메일 전송
	@Override
	public void sendEmail(String email, String key) {

		final String username = SettingValues.ADMIN;      // 본인 이메일
		final String password = SettingValues.PW;      // 본인 비밀번호
		final String host = "smtp.gmail.com";

		// SMTP(메일 서버) 설정
		// 아래 import는 pom.xml에 mail API를 설정해야 가능
		// import java.util.Properties;
		Properties props = new Properties();
		props.put("mail.smtp.user", username);			// SMTP에서 사용할 메일 주소
		props.put("mail.smtp.password", password);		// 비밀번호
		props.put("mail.smtp.host", host);				// host 서버 : gmail로 설정
		props.put("mail.smtp.port", "25");				// 25번 포트 사용
		props.put("mail.debug", "true");				// 디버그 설정
		props.put("mail.smtp.auth", "true");			// 인증 : true
		props.put("mail.smtp.starttls.enable", "true");	// tls 사용 허용
		props.put("mail.smtp.ssl.enable", "true");      // ssl 허용
		props.put("mail.smtp.ssl.trust", host);         // ssl 신뢰 가능으로 설정(보안레벨)

		// propert값 설정
		props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.setProperty("mail.smtp.socketFactory.fallback", "false");
		props.setProperty("mail.smtp.port", "465");
		props.setProperty("mail.smtp.socketFactory.port", "465");

		//import javax.mail.Session;
		//import javax.mail.Authenticator
		//import javax.mail.PasswordAuthentication

		Session session = Session.getInstance(props, new Authenticator() {
	         @Override
			protected PasswordAuthentication getPasswordAuthentication() {
	            return new PasswordAuthentication(username, password);
	         }
	      });

		//import javax.mail.Message
		//import javax.mail.internet.MimeMessage;
		//import javax.mail.internet.InternetAddress;
		//import javax.mail.Transport

		// emailChk.do를 컨트롤러에 작성
		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("admin@CosmoJspPJ.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));

			// localhost => 본인 IP => 원격 발표시 IP 수정
			// 링크를 클릭해서 "이메일 인증 성공" => enabled를 1로 update함
			String content ="회원가입을 축하드립니다. 링크를 눌러 회원가입을 완료하세요."
			+ "<a href='http://localhost/pj_jsr/emailChk.cu?key=" + key + "'>링크</a>";
			message.setSubject("회원가입 인증 메일");
			message.setContent(content, "text/html; charset=utf-8");

			Transport.send(message);
			System.out.println("<<<< Email SEND >>>>");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public int selectKey(String key) {
		System.out.println("DAO - selectKey()");
		return sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.selectKey", key);
	}

	@Override
	public int updateGrade(String key) {
		System.out.println("DAO - updateGrade()");
		return sqlSession.update("com.spring.pj_jsr.dao.CustomerDAO.updateGrade", key);
	}

}

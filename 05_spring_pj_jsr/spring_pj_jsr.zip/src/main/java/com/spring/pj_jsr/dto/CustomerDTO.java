package com.spring.pj_jsr.dto;

import java.sql.Date;

public class CustomerDTO {

	// 멤버변수 = 컬럼명 = input 태그명
	private String id;
	private String password;
	private String name;
	private String nickname;
	private Date birthday; // import java.sql.Date;
	private String address;
	private String hp;
	private String email;
	private Date indate; // import java.sql.Timestamp; > Date로 변경함
	private String grade; // 고객등급
	private String show; // 탈퇴여부
//	private List<BoardDTO> boardDTO; //board_tbl 내포, user 1명이 게시글을 여러건 남길 수 있다(spring_mvcMybatis ch03 참고)
	// 추가 - 시큐리티
	private String key;	// 이메일인증
	private String authority;	// 권한등급 : ROLE_USER : customer, ROLE_ADMIN : 관리자
	private String enabled;	//

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getIndate() {
		return indate;
	}
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "[CustomerDTO 클래스 정보]"
			+ "\n id : " + id
			+ "\n password : " + password
			+ "\n name : " + name
			+ "\n nickname : " + nickname
			+ "\n birthday : " + birthday
			+ "\n address : " + address
			+ "\n hp : " + hp
			+ "\n email : " + email
			+ "\n grade : " + grade
			+ "\n show : " + show
			+ "\n key : " + key
			+ "\n authority : " + authority
			+ "\n enabled : " + enabled;
	}
/*
	CREATE TABLE customer_tbl (
	    id          VARCHAR2(20)    PRIMARY KEY,
	    password    VARCHAR2(100)   NOT NULL,
	    name        VARCHAR2(20)    NOT NULL,
	    nickname    VARCHAR2(20)    NOT NULL UNIQUE,
	    birthday    DATE            NOT NULL,
	    address     VARCHAR2(100)   NOT NULL,
	    hp          VARCHAR2(13)    NOT NULL,
	    email       VARCHAR2(50)    NOT NULL UNIQUE,
	    indate      DATE            DEFAULT sysdate,
	    grade       VARCHAR2(30)    DEFAULT '일반',
	    show        CHAR(1)         DEFAULT 'y', -- 탈퇴시 update customer_tbl set show = 'n'
		-- 시큐리티를 위한 추가
	    key VARCHAR2(100),  -- 이메일인증
	    authority VARCHAR2(30) DEFAULT 'ROLE_USER', -- 권한  : ROLE_USER: customer, ROLE_ADMIN : 관리자
	    enabled  NUMBER(1)  DEFAULT 0   -- 계정사용 가능여부(사용가능 :1, 사용불가 :0)  : 이메일인증시 1로 UPDATE
	);
*/
}

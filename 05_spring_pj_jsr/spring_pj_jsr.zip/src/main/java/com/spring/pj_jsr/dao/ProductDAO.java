package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;

import com.spring.pj_jsr.dto.ProductDTO;

public interface ProductDAO {

	// 1. 재고/상품 개수 구하기
	int productCount();

	// 2. 재고/상품 목록 조회
	List<ProductDTO> productList(Map<String, Object> map);

	// 3. 카테고리별 재고/상품 목록
	List<ProductDTO> productListCategory(Map<String, Object> map);

	// 4. 재고/상품 상세 조회
	ProductDTO productRead(int p_code);

	// 5. 재고/상품 등록
	int productInsert(ProductDTO dto);

	// 6. 재고/상품 수정
	int productUpdate(ProductDTO dto);

	// 7. 재고/상품 삭제
	int productDelete(int p_code);

	// 8-1. 검색한 재고/상품 총 개수 - ALL
	int searchTotalAll(String keyword);

	// 8-2. 검색한 재고/상품 총 개수 - Category
	int searchTotalCategory(Map<String, Object> map);

	// 9-1 . 재고/상품 검색 - All
	List<ProductDTO> searchProductAll(Map<String, Object> map);

	// 9-1 . 재고/상품 검색 - Category
	List<ProductDTO> searchProductCategory(Map<String, Object> map);

	// 10. 재고 증가
	int plusStock(Map<String, Object> map);

	// 11. 재고 감소
	int minusStock(Map<String, Object> map);


}

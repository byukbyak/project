package com.spring.pj_jsr.service;

import java.util.ArrayList;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.spring.pj_jsr.dto.AdminDTO;
import com.spring.pj_jsr.dto.CustomerDTO;
import com.spring.pj_jsr.dto.UserVO;

// 인증처리 클래스
// login_check.do에 의해 호출된다
public class UserAuthenticationService implements UserDetailsService{

	@Autowired
	SqlSessionTemplate sqlSession;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	public UserAuthenticationService(SqlSessionTemplate sqlSession) {
		this.sqlSession = sqlSession;
	}

	/*
	 * 핵심코드
	 * 로그인 인증을 처리하는 메서드
	 * 1) 매개변수 userName을 id로 수정한다,
	 * 2) 매개변수로 전달된 아이디와 일치하는 레코드를 읽어온다.
	 * 3) 테이블의 암호화된 비밀번호와 사용자가 입력한 비밀번호를 내부적으로 비교처리
	 * 4) 정보가 없으면 예외처리를 발생시키고, 있으면 해당정보를 Map으로 리턴한다.
	 */
	@Override
	public UserDetails loadUserByUsername(String id) throws UsernameNotFoundException {
		System.out.println("UserAuthenticationService - loadUserByUsername 진입 >>");

		if(id.equals("bb")|| id.equals("bbyak") || id.equals("bbyuk")) {
			AdminDTO adminDTO = sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.adminInfo", id);
			System.out.println("로그인 체크 =>" + adminDTO);

			// 인증실패시 인위적으로 예외생성해서 던진다
			if(adminDTO == null)throw new UsernameNotFoundException(id);

			List<GrantedAuthority> authority = new ArrayList<GrantedAuthority>();
			authority.add(new SimpleGrantedAuthority(adminDTO.getAuthority()));	// 관리자 권한 설정

			return new UserVO(adminDTO.getAdmin_id(), adminDTO.getAdmin_pw(), adminDTO.getEnabled().equals("1"), true, true, true, authority);

		} else {
			CustomerDTO dto = sqlSession.selectOne("com.spring.pj_jsr.dao.CustomerDAO.selectCustomer", id);

			// 여기서는 DB에서 가지고 온 값을 가져온다.
			System.out.println("로그인 체크 =>" + dto);

			// 인증실패시 인위적으로 예외생성해서 던진다
			if(dto == null)throw new UsernameNotFoundException(id);
			List<GrantedAuthority> authority = new ArrayList<GrantedAuthority>();
			authority.add(new SimpleGrantedAuthority(dto.getAuthority()));	//default ROLE=User

			// UserVO클래스 먼저 생성한 후 return
			// 시큐리티로그인에서 체크 : id, password, authority(ROLE.USER/ ROLE_ADMIN), enabled(이메일 인증시 "1"로 update, 이메일 인증 후 시큐리티 적용)
			return new UserVO(dto.getId(), dto.getPassword(), dto.getEnabled().equals("1"), true, true, true, authority);
		}

	}
}

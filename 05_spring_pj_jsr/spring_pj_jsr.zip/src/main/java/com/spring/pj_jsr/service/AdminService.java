package com.spring.pj_jsr.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartHttpServletRequest;

public interface AdminService {

	// 공지사항 목록
	public void notice_list_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 공지사항 상세
	public void notice_read_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 공지사항 INSERT
	public void notice_insert_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 공지사항 UPDATE
	public void notice_udpate_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 공지사항 DELETE
	public void notice_delete_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 목록
	public void productListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 상세조회
	public void productReadAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 추가
	public void productAddAction(MultipartHttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 수정
	public void productUpdateAction(MultipartHttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 삭제
	public void productDeleteAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 검색
	public void productSearchList(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 주문 목록
	public void orderList(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 구매 승인
	public void orderConfirm(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 구매 거절
	public void orderReject(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 환불 목록
	public void refundList(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 환불 승인
	public void refundConfirm(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 환불 거절
	public void refundReject(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 18. 결산
	public void orderSales(HttpServletRequest req, Model model)
			throws ServletException, IOException;

}

package com.spring.pj_jsr.service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
public interface CustomerService {

	// 로그인 처리
	public void LoginAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 회원가입/정보수정 ] --------------------------------- */

	// 중복확인 처리
	public void confirmIdAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 회원가입 처리
	public void signInAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 회원정보 인증 및 탈퇴처리
	public void deleteCustomerAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 회원정보 인증 및 상세페이지
	public void modifyDetailAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 회원정보 수정 처리
	public void modifyCustomerAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 상품조회/검색 ] --------------------------------- */

	// 상품 조회
	public void selectProductListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품 검색처리
	public void productSearchList(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품상세 조회
	public void selectProductDetailAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 구매 ] --------------------------------- */

	// 바로구매 - 구매 페이지 없음
	public void now_buy(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 리뷰 ] --------------------------------- */

	// 상품리뷰 조회 - 전체
	public void selectReviewALL(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품리뷰 조회 - 특정
	public void selectReview(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품리뷰 등록
	public void insertReviewAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 상품리뷰 삭제
	public void deleteReviewAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 장바구니 ] --------------------------------- */

	// 장바구니 담기
	public void insertCartItemAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 장바구니 조회
	public void selectCartListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 장바구니 상품수정
	public void updateCartItemAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 장바구니 상품삭제(단수)
	public void deleteCartItemAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 장바구니 상품삭제(배열)
	public void deleteCartItemArr(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 장바구니 비우기
	public void deleteCartAllAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 장바구니 상품구매
	public void buyCartProduct(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 공지사항 ] --------------------------------- */

	// 공지사항 조회
	public void notice_list_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 공지사항 상세조회
	public void notice_read_action(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 게시판 ] --------------------------------- */

	// 게시판 조회
	public void selectBoardListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 게시판 상세조회
	public void selectBoardDetailAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 게시판 등록
	public void insertBoardAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 게시판 수정
	public void updateBoardAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 게시판 삭제
	public void deleteBoardAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 주문목록 ] --------------------------------- */

	// 주문 취소
	public void cancelOrderAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 구매 확정
	public void confirmOrder(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 환불 요청
	public void refundAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	// 환불 취소
	public void cancelRefundAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 마이페이지 메인 ] --------------------------------- */

	// 마이페이지 조회 - 주문목록
	public void selectMypageInfo(HttpServletRequest req, Model model)
			throws ServletException, IOException;

	/* --------------------------------- [ 이메일 체크 ] --------------------------------- */
	// 이메일 체크
	public void emailChkAction(HttpServletRequest req, Model model)
			throws ServletException, IOException;

}



package com.spring.pj_jsr.dto;

import java.sql.Date;

public class OrderDTO {

	private int order_no; 		// PK
	private int p_code; 		// FK
	private String id; 			// FK
	private String p_name;
	private String p_img;
	private int p_price;
	private int o_qty;
	private int r_qty;
	private int o_total;
	private int total_amount; 	// 총구매수량
	private int refund_amount; 	// 총환불수량
	private String o_status; 	// 구매요청, 구매취소, 구매승인, 환불요청, 환불승인, 환불취소, 환불완료
	private Date order_day;
	private Date refund_day;

	public OrderDTO() {}

	public OrderDTO(String id,int p_code, int o_qty, int p_price) {
		this.id = id;
		this.p_code = p_code;
		this.o_qty = o_qty;
		this.p_price = p_price;
		this.o_total = (o_qty*p_price);
	}

	public int getR_qty() {
		return r_qty;
	}
	public void setR_qty(int r_qty) {
		this.r_qty = r_qty;
	}
	public Date getOrder_day() {
		return order_day;
	}
	public void setOrder_day(Date order_day) {
		this.order_day = order_day;
	}
	public Date getRefund_day() {
		return refund_day;
	}
	public void setRefund_day(Date refund_day) {
		this.refund_day = refund_day;
	}
	public int getOrder_no() {
		return order_no;
	}
	public void setOrder_no(int order_no) {
		this.order_no = order_no;
	}
	public int getO_total() {
		return o_total;
	}
	public void setO_total(int o_total) {
		this.o_total = o_total;
	}
	public String getO_status() {
		return o_status;
	}
	public void setO_status(String o_status) {
		this.o_status = o_status;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getO_qty() {
		return o_qty;
	}
	public void setO_qty(int o_qty) {
		this.o_qty = o_qty;
	}
	public int getRefund_amount() {
		return refund_amount;
	}
	public void setRefund_amount(int refund_amount) {
		this.refund_amount = refund_amount;
	}
	public int getP_code() {
		return p_code;
	}
	public void setP_code(int p_code) {
		this.p_code = p_code;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_img() {
		return p_img;
	}
	public void setP_img(String p_img) {
		this.p_img = p_img;
	}
	public int getP_price() {
		return p_price;
	}
	public void setP_price(int p_price) {
		this.p_price = p_price;
	}
	public int getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	@Override
	public String toString() {
		return "[OrderDTO 정보]"
		+ "\n 주문번호 : "+order_no
		+ "\n 상품코드 : "+p_code
		+ "\n 아이디 : "+id
		+ "\n 상품명 : "+p_name
		+ "\n 이미지파일명 : "+p_img
		+ "\n 가격 : "+p_price
		+ "\n 주문수량 : "+o_qty
		+ "\n 환불수량 : "+o_qty
		+ "\n 주문별금액 : "+o_total
		+ "\n 총결제금액 : "+total_amount
		+ "\n 총환불금액 : "+refund_amount
		+ "\n 주문상태 : "+o_status
		+ "\n 주문일자 : "+order_day
		+ "\n 환불일자 : "+refund_day;
	}

}

/*
	CREATE TABLE order_tbl (
	    order_no NUMBER CONSTRAINT order_no_pk Primary key,
	    p_code NUMBER NOT NULL CONSTRAINT order_p_code_fk REFERENCES product_tbl(p_code) ON DELETE CASCADE,
	    id VARCHAR2(20) NOT NULL CONSTRAINT order_id_fk REFERENCES customer_tbl(id) ON DELETE CASCADE,
	    o_qty NUMBER NOT NULL,
	    o_total NUMBER NOT NULL,
	    o_status VARCHAR2(30) DEFAULT '구매요청',
	    order_day DATE DEFAULT sysdate,
	    refund_day DATE
	);
	-- o_status : 구매요청, 구매취소, 구매승인, 환불요청, 환불승인, 환불취소, 환불완료
*/
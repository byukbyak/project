package com.spring.pj_jsr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.pj_jsr.service.CustomerService;

@Controller
public class CustomerController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired // 서비스에서 저장한 주소값에 접근하기 위해 필요함
	CustomerService service;

	/* ---------------------------- [메인] ---------------------------- */
	@RequestMapping("main.cu")
	public String main(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /main.cu]");
		return "common/main";
	}
	/* ---------------------------- [회원가입] ---------------------------- */
	// 회원가입 페이지로 이동
	@RequestMapping("join.cu")
	public String join(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /join.cu]");
		return "customer/join/join";
	}
	// 아이디 중복확인(작은 창)
	@RequestMapping("id_check.cu")
	public String id_check(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /id_check.cu]");
		service.confirmIdAction(req, model);
		return "customer/join/id_check";
	}
	// 회원가입 INSERT
	@RequestMapping("join_insert.cu")
	public String join_insert(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /join_insert.cu]");
		service.signInAction(req, model);
		return "customer/join/join_insert";
	}
	/* ---------------------------- [로그인/로그아웃] ---------------------------- */
	// 로그인 화면
	@RequestMapping("login.cu")
	public String login(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /login.cu]");
		return "customer/login/login";
	}
	// 로그인 처리
	@RequestMapping("logout.cu")
	public String logout(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /logout.cu]");
		req.getSession().invalidate(); // 일괄 세션 삭제
		return "common/main";
	}
	/* ---------------------------- [회원정보 수정] ---------------------------- */
	// 회원정보 상세페이지
	@RequestMapping("modify_read.cu")
	public String modify_read(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /modify_read.cu]");
		service.modifyDetailAction(req, model);
		return "customer/mypage/customerInfo/modify_read";
	}
	// 회원정보 수정완료
	@RequestMapping("/modify_update.cu")
	public String modify_update(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : modify_update.cu]");
		service.modifyCustomerAction(req, model);
		return "customer/mypage/customerInfo/modify_update";
	}
	// 회원탈퇴 - 확인화면
	@RequestMapping("/delete_check.cu")
	public String delete_check(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : delete_check.cu]");
		return "customer/mypage/customerInfo/delete_check";
	}
	// 회원탈퇴 - 인증완료
	@RequestMapping("/delete_action.cu")
	public String delete_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : delete_action.cu]");
		service.deleteCustomerAction(req, model);
		return "customer/mypage/customerInfo/delete_action";
	}
	/* ---------------------------- [상품목록] ---------------------------- */
	// 상품목록 - 카테고리별 불러오기
	@RequestMapping("/goods_list.cu")
	public String goods_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : goods_list.cu]");
		service.selectProductListAction(req, model);
		return "customer/goods/goods_list";
	}
	// 상품상세
	@RequestMapping("/goods_read.cu")
	public String goods_read(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : goods_read.cu]");
		service.selectProductDetailAction(req, model);
		return "customer/goods/goods_read";
	}
	// 상품 검색
	@RequestMapping("/goods_search.cu")
	public String goods_search(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : goods_search.cu]");
		service.productSearchList(req, model);
		return "customer/goods/goods_search";
	}
	/* ---------------------------- [장바구니] ---------------------------- */
	// 장바구니 목록
	@RequestMapping("/cart_list.cu")
	public String cart_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cart_list.cu]");
		service.selectCartListAction(req, model);
		return "customer/cart/cart_list";
	}
	// 장바구니 추가
	@RequestMapping("/cart_add.cu")
	public String cart_add(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cart_add.cu]");
		service.insertCartItemAction(req, model);
		return "redirect:cart_list.cu";
	}
	// 장바구니 수정 처리
	@RequestMapping("/cart_update_action.cu")
	public String cart_update_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cart_update_action.cu]");
		service.updateCartItemAction(req, model);
		return "customer/cart/cart_update_action";
	}
	// 장바구니 삭제 처리(단수)
	@RequestMapping("/cart_delete_action.cu")
	public String cart_delete_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cart_delete_action.cu]");
		service.deleteCartItemAction(req, model);
		return "customer/cart/cart_delete_action";
	}
	// 장바구니 삭제 처리(배열)
	@RequestMapping("/cart_array_delete_action.cu")
	public String cart_array_delete_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cart_array_delete_action.cu]");
		service.deleteCartItemArr(req, model);
		return "redirect:cart_list.cu";
	}
	// 장바구니 비우기
	@RequestMapping("/cart_delete_all_action.cu")
	public String cart_delete_all_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cart_delete_all_action.cu]");
		service.deleteCartAllAction(req, model);
		return "customer/cart/cart_delete_all_action";
	}
	/* ---------------------------- [바로구매] ---------------------------- */
	// 바로구매 - 페이지 없음, 버튼 누르면 바로 INSERT
	@RequestMapping("/now_buy.cu")
	public String now_buy(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : now_buy.cu]");
		service.now_buy(req, model);
		int buyingResult = (Integer) req.getAttribute("buyingResult");
		return "redirect:mypage.cu?buyingResult="+buyingResult;
	}
	// 장바구니 - 구매
	@RequestMapping("/pay.cu")
	public String pay(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : pay.cu]");
		service.buyCartProduct(req, model);
		return "redirect:mypage.cu";
	}
	/* ---------------------------- [공지] ---------------------------- */
	// 공지사항 목록
	@RequestMapping("/notice_list.cu")
	public String notice_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : notice_list.cu]");
		service.notice_list_action(req, model);
		return "customer/notice/notice_list";
	}
	// 공지사항 상세
	@RequestMapping("/notice_read.cu")
	public String notice_read(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : notice_read.cu]");
		service.notice_read_action(req, model);
		return "customer/notice/notice_read";
	}
	/* ---------------------------- [마이페이지] ---------------------------- */
	// 마이페이지 메인 - 주문목록
	@RequestMapping("/mypage.cu")
	public String mypage(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : mypage.cu]");
		service.selectMypageInfo(req, model);
		return "customer/mypage/mypage";
	}
	/* ---------------------------- [주문] ---------------------------- */
	// 주문 취소
	@RequestMapping("/cancel_order_action.cu")
	public String cancel_order_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cancel_order_action.cu]");
		service.cancelOrderAction(req, model);
		return "redirect:mypage.cu";
	}
	// 구매 확정
	@RequestMapping("/confirm_order.cu")
	public String confirm_order(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : confirm_order.cu]");
		service.confirmOrder(req, model);
		return "redirect:mypage.cu";
	}
	// 환불 요청
	@RequestMapping("/refund_action.cu")
	public String refund_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : refund_action.cu]");
		service.refundAction(req, model);
		return "redirect:mypage.cu";
	}
	// 환불 취소
	@RequestMapping("/cancel_refund_action.cu")
	public String cancel_refund_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : cancel_refund_action.cu]");
		service.cancelRefundAction(req, model);
		return "redirect:mypage.cu";
	}
	/* ---------------------------- [시큐리티] ---------------------------- */
	// 시큐리티 - 가입성공시 이메일인증을 위해 이메일 인증 후 enabled 권한을 1로 update
	// CustomerDAOImpl의 sendEmail(String email, String key)에서 호출
	@RequestMapping("emailChk.cu")
	public String emailChk(HttpServletRequest req,  Model model) throws ServletException, IOException {
		logger.info("[url ==> emailChk.cu]");

		service.emailChkAction(req, model);
		return "customer/join/emailChkAction";
	}
}
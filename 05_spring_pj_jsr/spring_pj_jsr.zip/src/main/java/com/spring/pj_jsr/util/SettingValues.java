package com.spring.pj_jsr.util;

public interface SettingValues {

	// 여기랑, security context에도 적는다
	// 이메일 계정정보
	public static String ADMIN = "kosmo105jsr@gmail.com";	// 본인 이메일 계정
	public static String PW = "kosmo1234!";		// 본인 이메일 패스워드

}

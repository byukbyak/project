package com.spring.pj_jsr.dto;

public class SalesDTO {

	private String category;
	private int orderTotal;
	private int refundTotal;


	public SalesDTO() {}

	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getOrderTotal() {
		return orderTotal;
	}
	public void setOrderTotal(int orderTotal) {
		this.orderTotal = orderTotal;
	}
	public int getRefundTotal() {
		return refundTotal;
	}
	public void setRefundTotal(int refundTotal) {
		this.refundTotal = refundTotal;
	}

	@Override
	public String toString() {
		return "\n[SalesDTO 정보]"
				+ "\n category : " + category
				+ "\n orderTotal : " + orderTotal
				+ "\n refundTotal : " + refundTotal;
	}

}

package com.spring.pj_jsr.service;


import java.io.IOException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.spring.pj_jsr.dao.CustomerDAO;
import com.spring.pj_jsr.dao.NoticeDAO;
import com.spring.pj_jsr.dao.OrderDAO;
import com.spring.pj_jsr.dao.ProductDAO;
import com.spring.pj_jsr.dto.CartDTO;
import com.spring.pj_jsr.dto.CustomerDTO;
import com.spring.pj_jsr.dto.NoticeDTO;
import com.spring.pj_jsr.dto.OrderDTO;
import com.spring.pj_jsr.dto.ProductDTO;
import com.spring.pj_jsr.util.EmailChkHandler;
import com.spring.pj_jsr.util.Paging;

@Service
public class CustomerServiceImpl implements CustomerService{

	/*
		[목차]
		1. 로그인 처리
		2. 아이디 중복확인 처리
		3. 회원가입 처리
		4. 회원정보 인증 및 탈퇴처리
		5. 회원정보 인증 및 상세페이지
		6. 회원정보 수정 처리
		7. 상품 조회
		8. 상품 검색 데이터 조회 - 검색이 뭔가 잘 안되고있음
		9. 상품상세 조회
		10. 바로 구매
		11. 장바구니 담기
		12. 장바구니 조회
		13. 장바구니 상품수정
		14. 장바구니 상품 개별 삭제
		15. 장바구니 비우기
		16. 장바구니 상품구매
		18. 주문 취소
		19. 구매 확정
		20. 환불 요청
		21. 환불 취소
		22. 마이페이지 조회 - 주문목록 조회
		23. 공지사항 조회
		24. 공지사항 상세조회
	*/

	@Autowired
	ProductDAO productdao;

	@Autowired
	CustomerDAO customerDAO;

	@Autowired
	NoticeDAO noticeDAO;

	@Autowired
	OrderDAO orderDAO;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;   // 비밀번호 암호화 클래스

	@Override // 1. 로그인 처리 - 시큐리티
	public void LoginAction(HttpServletRequest req, Model model) {
		System.out.println("서비스 - LoginAction 사용안함");
	}

	@Override // 2. 아이디 중복확인 처리
	public void confirmIdAction(HttpServletRequest req, Model model) {
		System.out.println("서비스 - confirmIdAction");
		String strId = req.getParameter("id");
		int selectCnt = customerDAO.idCheck(strId);

		model.addAttribute("id", strId); //id라는 이름으로 컨트롤러 -> jsp로 보냄.
		model.addAttribute("selectCnt", selectCnt); // (DAO의 executeQuery결과가 0:조회실패=중복아님 아니면 1:조회성공=중복있음이 담겨있음)
	}

	@Override // 3. 회원가입 처리 - 시큐리티
	public void signInAction(HttpServletRequest req, Model model) {
		System.out.println("서비스 - signInAction");

		String password = req.getParameter("password");
		System.out.println("암호화 전의 비밀번호 : " + password);

		// BCryptPasswordEncoder.encode() : 비밀번호 암호화 메서드
		String encryptPassword = passwordEncoder.encode(password);
		System.out.println("암호화 후의 비밀번호 : " + encryptPassword);

		CustomerDTO dto = new CustomerDTO();
		dto.setId(req.getParameter("id"));
		dto.setPassword(encryptPassword); // setPassword(암호화된 비밀번호);
		dto.setName(req.getParameter("name"));
		dto.setNickname(req.getParameter("nickname"));
		String strDate = req.getParameter("birthday");
		Date date = Date.valueOf(strDate);
		dto.setBirthday(date);

		String address = req.getParameter("address_code") + "_"
			       + req.getParameter("address") + "_"
			       + req.getParameter("address_detail") + "_"
			       + req.getParameter("address_extra");
		dto.setAddress(address);

		// 핸드폰
		String hp = "";
		String strHp1 = req.getParameter("hp1");
		String strHp2 = req.getParameter("hp2");
		String strHp3 = req.getParameter("hp3");

		if(!strHp1.equals("") && !strHp2.equals("") && !strHp3.equals("")) {
			hp = strHp1 + "-" + strHp2 + "-" + strHp3;
		}
		dto.setHp(hp);

		// 이메일 값 입력하는곳이 2개이므로 이어주기
		String email = "";
		String strEmail1 = req.getParameter("email1");
		String strEmail2 = req.getParameter("email2");
		email = strEmail1 + "@" + strEmail2;
		dto.setEmail(email);

		// 시큐리티
		String key = EmailChkHandler.getKey();
		dto.setKey(key);

		int insertCnt = customerDAO.insertCustomer(dto);
		System.out.println("서비스 insertCnt : "+insertCnt);

		// 시큐리티 - 가입성공시 이메일인증을 위해 이메일 전송
		if(insertCnt == 1) {
			customerDAO.sendEmail(email, key);   // email은 반드시 가입한 구글계정 이메일
		}

		model.addAttribute("insertCnt", insertCnt);
		// login.jsp 에서 key값인 insertCnt 활용해서 값을 전달한다.
	}

	@Override // 시큐리티 - 이메일 체크
	public void emailChkAction(HttpServletRequest req, Model model)
			throws ServletException, IOException{

		String key = req.getParameter("key");
		int selectCnt = customerDAO.selectKey(key);

		if(selectCnt == 1) {
			int insertCnt = customerDAO.updateGrade(key);
			model.addAttribute("insertCnt", insertCnt);
		}
	}

	@Override // 4. 회원정보 인증 및 탈퇴처리
	public void deleteCustomerAction(HttpServletRequest req, Model model) {
		System.out.println("서비스 - deleteCustomerAction");
		//  입력값 전달받기
		String strId = (String)req.getSession().getAttribute("sessionId");

		int deleteCnt = customerDAO.deleteCustomer(strId);
		System.out.println("탈퇴서비스 deleteCnt : "+deleteCnt);

		model.addAttribute("deleteCnt", deleteCnt);
	}

	@Override // 5. 회원정보 인증 및 상세페이지
	public void modifyDetailAction(HttpServletRequest req, Model model) {
		System.out.println("서비스 - modifyDetailAction");

		String strId = (String)req.getSession().getAttribute("sessionId"); // 세션ID - 왜냐? 이미 입력된거 화면에 띄워줄려고
		CustomerDTO dto = customerDAO.getCustomerDetail(strId);
		model.addAttribute("dto", dto);
	}

	@Override // 6. 회원정보 수정 처리
	public void modifyCustomerAction(HttpServletRequest req, Model model) {
		System.out.println("서비스 - modifyCustomerAction");

		// 회원정보 인증 및 상세페이지
		// 비밀번호 암호화 수행
		String password = req.getParameter("password");
		System.out.println("암호화 전의 비밀번호 : " + password);

		String encryptPassword = passwordEncoder.encode(password);
		System.out.println("암호화 후의 비밀번호 : " + encryptPassword);

		CustomerDTO dto = new CustomerDTO();
		dto.setId((String)req.getSession().getAttribute("sessionId"));
		dto.setPassword(encryptPassword);
		dto.setName(req.getParameter("name"));
		dto.setNickname(req.getParameter("nickname"));
		String strBirthday = req.getParameter("birthday");
		Date birthday = Date.valueOf(strBirthday);
		dto.setBirthday(birthday);

		String address = req.getParameter("address_code") + "_"
			       + req.getParameter("address") + "_"
			       + req.getParameter("address_detail") + "_"
			       + req.getParameter("address_extra");
		dto.setAddress(address);

		String hp = "";
		String hp1 = req.getParameter("hp1");
		String hp2 = req.getParameter("hp2");
		String hp3 = req.getParameter("hp3");
		if(!hp1.equals("") && !hp2.equals("") && !hp3.equals("")) {
			hp = hp1+"-"+hp2+"-"+hp3;
		}
		dto.setHp(hp);

		String email = "";
		String email1 = req.getParameter("email1");
		String email2 = req.getParameter("email2");
		if(!email1.equals("") && !email2.equals("")) {
			email = email1+"@"+email2;
		}
		dto.setEmail(email);

		System.out.println("dto.getPassword() : "+dto.getPassword());
		System.out.println("dto.getName() : "+dto.getName());
		System.out.println("dto.getNickname() : "+dto.getNickname());
		System.out.println("dto.getBirthday() : "+dto.getBirthday());
		System.out.println("dto.getAddress() : "+dto.getAddress());
		System.out.println("dto.getHp() : "+dto.getHp());
		System.out.println("dto.getEmail() : "+dto.getEmail());
		System.out.println("dto.getId() : "+dto.getId());

		//  회원수정 처리
		int updateCnt = customerDAO.updateCustomer(dto);
		System.out.println("updateCnt : "+updateCnt);
		model.addAttribute("updateCnt", updateCnt);

	}

	@Override // 7. 상품 조회
	public void selectProductListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productListAction");

		String pageNum = req.getParameter("pageNum");
		String category = req.getParameter("p_category");
		System.out.println("category : " + category);

		// 페이지 처리
		Paging paging = new Paging(pageNum);
		List<ProductDTO> list = null;

		// 전체 게시글 개수
		int total = productdao.productCount();
		System.out.println("total : "+total);
		paging.setTotalCount(total);

		int start = paging.getStartRow();
		int end = paging.getEndRow();

		Map<String, Object> map = null;
		// 카테고리가 없으면
		if (category == null || category == "") {
			map = new HashMap<String, Object>();
			map.put("start", start);
			map.put("end", end);
			// DB에서 전체 조회
			list = productdao.productList(map);
		// 카테고리가 있으면
		} else {
			map = new HashMap<String, Object>();
			map.put("start", start);
			map.put("end", end);
			map.put("category", category);
			// 해당 카테고리로 DB에서 조회
			list = productdao.productListCategory(map);
		}
		System.out.println("list : "+list);

		String p_category = "";
		if (category == null) p_category="ALL";
		else if(category.equals("SMART TOK")) p_category = "SMART TOK";
		else if(category.equals("PHONE ACC.")) p_category = "PHONE ACC.";
		else if(category.equals("STICKER")) p_category = "STICKER";
		else if(category.equals("ETC.")) p_category = "ETC.";

		model.addAttribute("list", list);
		model.addAttribute("p_category", p_category);
		model.addAttribute("paging", paging);

	}

	@Override // 8. 상품 검색 데이터 조회
	public void productSearchList(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productSearchList");

		// 검색한 단어, 상품 카테고리, 페이지 번호
		String keyword = req.getParameter("keyword");
		String category = req.getParameter("p_category");
		String pageNum = req.getParameter("pageNum");
		System.out.println("keyword : " + keyword);
		System.out.println("category : " + category);

		Paging paging = new Paging(pageNum);

		int total = 0;

		Map<String, Object> map1 = new HashMap<String, Object>();
		map1.put("category", category);
		map1.put("keyword", keyword);

//		productdao.searchTotal(map1);
		System.out.println("total : " + total);
		paging.setTotalCount(total);

		int start = paging.getStartRow();
		int end = paging.getEndRow();

		Map<String, Object> map2 = new HashMap<String, Object>();
		map2.put("start", start);
		map2.put("end", end);
		map2.put("category", category);
		map2.put("keyword", keyword);

//		List<ProductDTO> list = productdao.searchProduct(map2);

		String p_category = "";
		if (category == null) p_category="ALL";
		else if(category.equals("SMART TOK")) p_category = "SMART TOK";
		else if(category.equals("PHONE ACC")) p_category = "PHONE ACC";
		else if(category.equals("STICKER")) p_category = "STICKER";
		else if(category.equals("ETC.")) p_category = "ETC.";

		model.addAttribute("p_category", p_category);
		model.addAttribute("category", category);
		model.addAttribute("keyword", keyword);
		model.addAttribute("paging", paging);
		model.addAttribute("pageNum", pageNum);
//		model.addAttribute("list", list);

	}

	@Override // 9. 상품상세 조회
	public void selectProductDetailAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productReadAction()");

		int p_code = Integer.parseInt(req.getParameter("p_code"));
		ProductDTO dto = productdao.productRead(p_code);
		model.addAttribute("dto", dto);
	}

	@Override // 10. 바로 구매
	public void now_buy(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - now_buy");

		// 파라미터, 세션에 있는 id, p_code, c_qty를 받아서 o_qty
		String strId = (String)req.getSession().getAttribute("sessionId");
		int p_code = Integer.parseInt(req.getParameter("p_code"));
		int p_price = Integer.parseInt(req.getParameter("p_price"));
		int o_qty = Integer.parseInt(req.getParameter("c_qty"));
		OrderDTO dto = new OrderDTO(strId, p_code, o_qty, p_price);

		int buyingResult = orderDAO.now_buy(dto);
		if(buyingResult == 0) {
			System.out.println("바로구매 실패");
		} else {
			System.out.println("바로구매 성공");
		}
		// JSP로 값 전달
		req.setAttribute("buyingResult", buyingResult);

	}

	@Override // 11. 장바구니 담기
	public void insertCartItemAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - insertCartItemAction");

		// 파라미터값으로 받아오기 p_code/c_qty + 세션에서 id 받기
		String strId = (String)req.getSession().getAttribute("sessionId");
		int p_code = Integer.parseInt(req.getParameter("p_code"));
		int c_qty = Integer.parseInt(req.getParameter("c_qty"));

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("strId", strId);
		map.put("p_code", p_code);
		map.put("c_qty", c_qty);

		// 값 DAO로 넘겨주기
		int cnt = orderDAO.cart_add(map);
		if(cnt == 0) {
			System.out.println("장바구니 담기 실패");
		} else {
			System.out.println("장바구니 담기 성공");
		}

		// JSP로 값 전달
		model.addAttribute("cnt", cnt);
	}

	@Override // 12. 장바구니 조회
	public void selectCartListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - selectCartListAction");
		String strId = (String)req.getSession().getAttribute("sessionId");

		List<CartDTO> list = new ArrayList<CartDTO>();
		list = orderDAO.cart_read(strId);
		System.out.println("서비스 - list : " + list);

		model.addAttribute("list", list);
	}

	@Override // 13. 장바구니 상품수정
	public void updateCartItemAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - updateCartItemAction");

		// 1. 장바구니의 번호와 변경할 수량을 받아옵니다.
		int c_num = Integer.parseInt(req.getParameter("c_num"));
		int c_qty = Integer.parseInt(req.getParameter("c_qty"));
		System.out.println("c_num : " + c_num);
		System.out.println("c_qty : " + c_qty);

		// 2. DAO를 생성하여 해당 장바구니의 상품 수량을 DB에서 변경합니다.
		int updateResult = 0;

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("c_num", c_num);
		map.put("c_qty", c_qty);

		updateResult = orderDAO.updateCartItemAmount(map);

		// 3. request 객체에 결과를 저장합니다.
		model.addAttribute("updateResult", updateResult);
	}

	@Override // 14-1. 장바구니 상품 개별 삭제(단수)
	public void deleteCartItemAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - deleteCartItemAction");

		// 1. 장바구니의 번호들을 받아옵니다.
		int c_num = Integer.parseInt(req.getParameter("c_num"));

		// 2. DAO를 생성하여 해당 장바구니를 DB에서 삭제합니다.
		int deleteResult = 0;
		deleteResult = orderDAO.deleteCartItem(c_num);

		// 3. request 객체에 결과를 저장합니다.
		model.addAttribute("deleteResult", deleteResult);
	}

	@Override // 14-2. 장바구니 상품 개별 삭제(배열)
	public void deleteCartItemArr(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - deleteCartItemAction");

		// 1. 장바구니의 번호들을 받아옵니다.
		String[] data = req.getParameterValues("c_num_arr");
		System.out.println("data : "+data);
		String[] c_num_arr = data[0].split(",");
		System.out.println("c_num_arr : "+c_num_arr);

		// 2. DAO를 생성하여 해당 장바구니를 DB에서 삭제합니다.
		int deleteResult = 0;
		deleteResult = orderDAO.deleteCartItemArr(c_num_arr);

		// 3. request 객체에 결과를 저장합니다.
		model.addAttribute("deleteResult", deleteResult);
	}

	@Override // 15. 장바구니 비우기
	public void deleteCartAllAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - deleteCartAllAction");

		// 1. DAO를 생성하여 장바구니를 DB에서 삭제합니다.
		int deleteResult = 0;
		deleteResult = orderDAO.deleteCartAll();

		// 2. request 객체에 결과를 저장합니다.
		model.addAttribute("deleteResult", deleteResult);

	}

	@Override // 16. 장바구니 상품구매
	public void buyCartProduct(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - buyCartProduct");

		// 1-1. 화면에서 데이터를 받아온다.
		String customer_id = (String)req.getSession().getAttribute("sessionId");

		String[] data = req.getParameterValues("c_num_arr");
		System.out.println("data : "+data);
		String[] c_num_arr = data[0].split(",");
		System.out.println("c_num_arr : " + c_num_arr);

		// 2. 주문에 넣을 데이터들을 담을 큰 바구니 생성

		List<OrderDTO> olist = new ArrayList<OrderDTO>();
		List<CartDTO> clist = new ArrayList<CartDTO>();

		// 장바구니 구매인 경우

		// 현재 고객의 장바구니 목록 조회
		clist = orderDAO.selectPayList(c_num_arr);
		System.out.println("clist : " + clist);

		// 큰 바구니에 담을 DTO를 생성하여 데이터를 등록 후 olist에 추가
		for (CartDTO cart : clist) {
			OrderDTO dto = new OrderDTO(customer_id, cart.getP_code(), cart.getC_qty(), cart.getP_price());
			olist.add(dto);
		}
		System.out.println("olist : " + olist);

		// 3. DAO를 생성하여 DB에서 주문목록을 등록한다.
		int insertResult = 0;
		insertResult = orderDAO.insertOrder(olist);
		System.out.println("insertResult : " + insertResult);

		// 2-2. 주문 등록에 성공하면 장바구니 내역 삭제
		int deleteResult = 0;
		if (insertResult != 0) {
			deleteResult = orderDAO.deleteCartItemArr(c_num_arr);
			System.out.println("deleteResult : "+deleteResult);
		}

		// 3. request에 결과를 저장한다.
		model.addAttribute("insertResult", insertResult);
		model.addAttribute("deleteResult", deleteResult);
	}

	@Override // 18. 주문 취소
	public void cancelOrderAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - cancelOrderAction");

		// 1. 주문번호를 받아옵니다.
		int order_no = Integer.parseInt(req.getParameter("order_no"));
		String state = "주문취소";

		// 2. DAO를 생성하여 DB에서 해당 주문상태를 변경합니다.
		int updateResult = 0;

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("order_no", order_no);
		map.put("state", state);

		updateResult = orderDAO.updateState(map);

		// 3. 결과를 저장합니다.
		model.addAttribute("updateResult", updateResult);

	}

	@Override // 19. 구매 확정
	public void confirmOrder(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - cancelOrderAction");

		// 1. 주문번호를 받아옵니다.
		int order_no = Integer.parseInt(req.getParameter("order_no"));
		String state = "구매확정";

		// 2. DAO를 생성하여 DB에서 해당 주문상태를 변경합니다.
		int updateResult = 0;

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("order_no", order_no);
		map.put("state", state);

		updateResult = orderDAO.updateState(map);

		// 3. request 객체에 결과를 저장합니다.
		model.addAttribute("updateResult", updateResult);

	}

	@Override // 20. 환불 요청
	public void refundAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - refundAction");

		// 1. 주문번호를 받아옵니다.
		int order_no = Integer.parseInt(req.getParameter("order_no"));
		String state = "환불요청";

		// 2. DAO를 생성하여 DB에서 해당 주문상태를 변경합니다.
		int updateResult = 0;

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("order_no", order_no);
		map.put("state", state);

		updateResult = orderDAO.updateState(map);

		// 3. request 객체에 결과를 저장합니다.
		model.addAttribute("updateResult", updateResult);

	}

	@Override // 21. 환불 취소
	public void cancelRefundAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - cancelRefundAction");

		// 1. 주문번호를 받아옵니다.
		int order_no = Integer.parseInt(req.getParameter("order_no"));
		String state = "환불취소";

		// 2. DAO를 생성하여 DB에서 해당 주문상태를 변경합니다.
		int updateResult = 0;

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("order_no", order_no);
		map.put("state", state);

		updateResult = orderDAO.updateState(map);

		// 3. request 객체에 결과를 저장합니다.
		model.addAttribute("updateResult", updateResult);

	}

	@Override // 22. 마이페이지 조회
	public void selectMypageInfo(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - selectMypageInfo");

		String pageNum = req.getParameter("pageNum");
		Paging paging = new Paging(pageNum);

		String id = (String)req.getSession().getAttribute("sessionId");

		int total = orderDAO.customerOrderCount(id); // 고객 주문 총 개수
		paging.setTotalCount(total);

		// 1을 클릭하면 1 10, 2를 클릭하면 11 20
		int start = paging.getStartRow();
		int end = paging.getEndRow();

		int RefundCount = orderDAO.selectRefundTotal(id); // 환불 총 개수
		System.out.println("RefundCount : " + RefundCount);
		List<OrderDTO> list = new ArrayList<OrderDTO>();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);
		map.put("id", id);

		list = orderDAO.selectOrderList(map);

		model.addAttribute("order_total", total);
		model.addAttribute("refund_total", RefundCount );
		model.addAttribute("list", list );

	}

	@Override // 23. 공지사항 조회
	public void notice_list_action(HttpServletRequest req, Model model)
			throws ServletException, IOException{
		// 해당 페이지 번호 클릭시
		String pageNum = req.getParameter("pageNum");

		Paging paging = new Paging(pageNum);

		// 전체 게시글 개수
		int total = noticeDAO.noticeCnt();
		System.out.println("total : " + total);
		paging.setTotalCount(total);

		// 1을 클릭하면 1 10, 2를 클릭하면 11 20
		int start = paging.getStartRow();
		int end = paging.getEndRow();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);

		List<NoticeDTO> list = noticeDAO.notice_list(map);

		model.addAttribute("list", list);
		model.addAttribute("paging", paging);
	}

	@Override // 24. 공지사항 상세조회
	public void notice_read_action(HttpServletRequest req, Model model)
			throws ServletException, IOException{
		System.out.println("서비스 - notice_read_action");

		int notice_no = Integer.parseInt(req.getParameter("notice_no"));
		System.out.println("notice_no : "+notice_no);

		noticeDAO.plusReadCnt(notice_no);
		NoticeDTO dto = noticeDAO.notice_read(notice_no);

		String content = dto.getContent();
		if(content != null) {
			content = content.replace("\n", "<br>");
		}
		dto.setContent(content);

		model.addAttribute("dto", dto);
		model.addAttribute("notice_no", notice_no);
	}

	@Override // 25. 상품리뷰 조회 - 전체
	public void selectReviewALL(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 26. 상품리뷰 조회 - 특정
	public void selectReview(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 27. 상품리뷰 등록
	public void insertReviewAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 28. 상품리뷰 삭제
	public void deleteReviewAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 29. 게시판 조회
	public void selectBoardListAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 30. 게시판 상세조회
	public void selectBoardDetailAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 31. 게시판 등록
	public void insertBoardAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 32. 게시판 수정
	public void updateBoardAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	@Override // 33. 게시판 삭제
	public void deleteBoardAction(HttpServletRequest req, Model model) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

}

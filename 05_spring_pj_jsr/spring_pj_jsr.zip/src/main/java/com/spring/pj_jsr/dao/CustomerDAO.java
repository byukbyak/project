package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;

import com.spring.pj_jsr.dto.AdminDTO;
import com.spring.pj_jsr.dto.CustomerDTO;

public interface CustomerDAO {

	// 1-1. 중복확인 처리 / 시큐리티 - UserLoginFailureHandler
	public int idCheck(String strId);

	// 1-2. 비밀번호 확인 / 시큐리티 - UserLoginFailureHandler
//	pwdCheck

	// 1-3. 권한체크 / 시큐리티 - UserLoginSuccessHandler
//	authorityCheck

	// 1-4. 이메일인증시 호출 / 시큐리티 - UserAuthenticationService
//	selectCustomer

	// 시큐리티 : 로그인 전 이메일 인증을 해야 하며, 1로 수정
	public int selectKey(String key);

	// 시큐리티
	public int updateGrade(String key);

	// sendEmail
	public void sendEmail(String email, String key);

	// 9. 회원정보 DB 조회 - 관리자
	CustomerDTO selectCustomer(String strId);

	// 2. 회원가입 처리
	public int insertCustomer(CustomerDTO dto);

	// 3. 로그인 처리 / 회원정보 인증(수정, 탈퇴)
	public int idPasswordChk(Map<String, Object> map);

	// 4. 회원정보 인증 및 탈퇴처리
	public int deleteCustomer(String strId);

	// 5. 회원정보 인증 및 상세페이지
	public CustomerDTO getCustomerDetail(String strId);

	// 6. 회원정보 수정 처리
	public int updateCustomer(CustomerDTO dto);

	// 7-1. 관리자 정보 가져오기
	public AdminDTO getAdminInfo(String strId);

	// 7. 닉네임 가져오기
	public String getNickName(String strId);

	// 8. 등급 가져오기
	public String getGrade(String strId);

	// 10. 회원정보 전체 조회
	List<CustomerDTO> selectCustomerList(Map<String, Object> map);

	// 11. 전체 회원 수
	int selectCustomerTotal();

	// 12. 관리자 아이디, 비밀번호 확인
	int adminCheck(Map<String, Object> map);


}

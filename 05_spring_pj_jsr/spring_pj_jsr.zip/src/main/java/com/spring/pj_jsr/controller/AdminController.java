package com.spring.pj_jsr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.pj_jsr.service.AdminService;

@Controller
public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired // 서비스에서 저장한 주소값에 접근하기 위해 필요함
	AdminService service;

	/* ---------------------------- [재고] ---------------------------- */
	// 관리자 메인 / 재고목록
	@RequestMapping("product_list.ad")
	public String product_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /product_list.ad]");
		service.productListAction(req, model);
		return "manager/stock/product_list";
	}
	// 재고상세조회
	@RequestMapping("product_read.ad")
	public String product_read(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /product_read.ad]");
		service.productReadAction(req, model);
		return "manager/stock/product_read";
	}
	// 재고추가
	@RequestMapping("product_add.ad")
	public String product_add(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /product_add.ad]");
		return "manager/stock/product_add";
	}
	// 재고추가 insert / 파일 업로드
	@RequestMapping("product_insert.ad")
	public String product_insert(MultipartHttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /product_insert.ad]");
		service.productAddAction(req, model);
		return "manager/stock/product_insert";
	}
	// 재고수정
	@RequestMapping("product_update.ad")
	public String product_update(HttpServletRequest req, Model model) throws ServletException, IOException {
		logger.info("[url : /product_update.ad]");
		service.productReadAction(req, model);
		return "manager/stock/product_update";
	}
	// 재고수정
	@RequestMapping("product_update_action.ad")
	public String product_update_action(MultipartHttpServletRequest req, Model model) throws ServletException, IOException {
        logger.info("[url : /product_update_action.ad]");
        service.productUpdateAction(req, model);
        return "manager/stock/product_update_action";
	}
	// 재고삭제
	@RequestMapping("product_delete.ad")
	public String product_delete(HttpServletRequest req, Model model) throws ServletException, IOException {
        logger.info("[url : /product_delete.ad]");
        service.productDeleteAction(req, model);
        return "redirect:product_list.ad";
	}
	/* ---------------------------- [notice] ---------------------------- */
	// 공지사항 목록
	@RequestMapping("/notice_list.ad")
	public String notice_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_list.ad]");
		service.notice_list_action(req, model);
		return "manager/notice/notice_list";
	}
	// 공지사항 상세
	@RequestMapping("/notice_read.ad")
	public String notice_read(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_read.ad]");
		service.notice_read_action(req, model);
		return "manager/notice/notice_read";
	}
	// 공지사항 등록
	@RequestMapping("/notice_add.ad")
	public String notice_add(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_add.ad]");
		return "manager/notice/notice_add";
	}
	// 공지사항 INSERT
	@RequestMapping("/notice_insert_action.ad")
	public String notice_insert_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_insert_action.ad]");
		service.notice_insert_action(req, model);
		return "redirect:notice_list.ad";
	}
	// 공지사항 수정
	@RequestMapping("/notice_update.ad")
	public String notice_update(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_update.ad]");
		service.notice_read_action(req, model);
		return "manager/notice/notice_update";
	}
	// 공지사항 UPDATE
	@RequestMapping("/notice_update_action.ad")
	public String notice_update_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_update_action.ad]");
		service.notice_udpate_action(req, model);
		int notice_no = (Integer) req.getAttribute("notice_no");
		return "redirect:notice_read.ad?notice_no="+notice_no;
	}
	// 공지사항 DELETE
	@RequestMapping("/notice_delete.ad")
	public String notice_delete(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /notice_delete.ad]");
		service.notice_delete_action(req, model);
		return "redirect:notice_list.ad?";
	}
	/* ---------------------------- [review] ---------------------------- */
	// 리뷰 목록
	@RequestMapping("/review_list.ad")
	public String review_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /review_list.ad]");
		return "manager/review/review_list";
	}
	/* ---------------------------- [member] ---------------------------- */
	// 회원 목록
	@RequestMapping("/member_list.ad")
	public String member_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /member_list.ad]");
//		service.customerList(req, model);
		return "manager/member/member_list";
	}
	// 회원 삭제
	@RequestMapping("/member_delete.ad")
	public String member_delete(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /member_delete.ad]");
//		service.customerDeleteAction(req, model);
		return "manager/member/member_delete";

	}
	/* ---------------------------- [order] ---------------------------- */
	// 주문 목록
	@RequestMapping("/order_list.ad")
	public String order_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /order_list.ad]");
		service.orderList(req, model);
		return "manager/orders/order_list";
	}
	// 구매 승인
	@RequestMapping("/order_confirm_action.ad")
	public String order_confirm_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /order_confirm_action.ad]");
		service.orderConfirm(req, model);
		return "manager/orders/order_confirm_action";
	}
	// 구매 거절
	@RequestMapping("/order_cancel_action.ad")
	public String order_cancel_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /order_cancel_action.ad]");
		service.orderReject(req, model);
		return "manager/orders/order_cancel_action";
	}
	/* ---------------------------- [refund] ---------------------------- */
	// 환불 목록
	@RequestMapping("/refund_list.ad")
	public String refund_list(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /refund_list.ad]");
		service.refundList(req, model);
		return "manager/refund/refund_list";
	}
	// 환불 승인
	@RequestMapping("/refund_confirm_action.ad")
	public String refund_confirm_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /refund_confirm_action.ad]");
		service.refundConfirm(req, model);
		return "manager/orders/refund_confirm_action";
	}
	// 환불 거부
	@RequestMapping("/refund_cancel_action.ad")
	public String refund_cancel_action(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /refund_cancel_action.ad]");
		service.refundReject(req, model);
		return "manager/orders/refund_cancel_action";
	}
	/* ---------------------------- [refund] ---------------------------- */
	// 결산
	@RequestMapping("/order_sales.ad")
	public String order_sales(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("[url : /order_sales.ad]");
		service.orderSales(req, model);
		return "manager/sales/order_sales";
	}
	/* ---------------------------- [logout] ---------------------------- */
	@RequestMapping("/logout.ad")
	public String logout(HttpServletRequest req) throws ServletException, IOException {
		System.out.println("[url : logout.ad]");
		req.getSession().invalidate();
		return "common/main";
	}

}

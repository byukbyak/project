package com.spring.pj_jsr.dto;

import java.sql.Date;

public class NoticeDTO {

	public int notice_no;
	public String title;
	public String content;
	public String writer;
	public int readCnt;
	public Date indate;
	public String show;

	public int getNotice_no() {
		return notice_no;
	}
	public void setNotice_no(int notice_no) {
		this.notice_no = notice_no;
	}
	public String getShow() {
		return show;
	}
	public void setShow(String show) {
		this.show = show;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public int getReadCnt() {
		return readCnt;
	}
	public void setReadCnt(int readCnt) {
		this.readCnt = readCnt;
	}
	public Date getIndate() {
		return indate;
	}
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	@Override
	public String toString() {
		return "[NoticeDTO - 정보]"
				+ "\n notice_no : "+notice_no
				+ "\n title : "+title
				+ "\n content : "+content
				+ "\n writer : "+writer
				+ "\n readCnt : "+readCnt
				+ "\n indate : "+indate;
	}
}

/*
	CREATE TABLE notice_tbl (
	    notice_no NUMBER PRIMARY KEY,
	    title VARCHAR(50) NOT NULL,
	    content CLOB,
	    writer VARCHAR(20) NOT NULL CONSTRAINT notice_writer_fk REFERENCES admin_tbl(admin_nick) ON DELETE CASCADE,
	    readCnt NUMBER DEFAULT 0,
	    indate DATE DEFAULT sysdate,
	    show CHAR(1) DEFAULT 'y'
	);
*/
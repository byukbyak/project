package com.spring.pj_jsr.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.spring.pj_jsr.dao.NoticeDAO;
import com.spring.pj_jsr.dao.OrderDAO;
import com.spring.pj_jsr.dao.ProductDAO;
import com.spring.pj_jsr.dto.NoticeDTO;
import com.spring.pj_jsr.dto.OrderDTO;
import com.spring.pj_jsr.dto.ProductDTO;
import com.spring.pj_jsr.dto.SalesDTO;
import com.spring.pj_jsr.util.Paging;

@Service
public class AdminServiceImpl implements AdminService {

	/*
		[목차]
		1. 공지사항 글 목록
		2. 공지사항 글 상세
		3. 공지사항 등록
		4. 공지사항 수정
		5. 공지사항 삭제
		6. 재고목록
		7. 재고상세
		8. 재고추가
		9. 재고수정
		10. 재고삭제
		11. 재고검색 - X
		12. 주문목록
		13. 구매승인
		14. 구매거절
		15. 환불목록
		16. 환불승인
		17. 환불거절
		18. 결산
	*/

	@Autowired
	ProductDAO productDAO;

	@Autowired
	NoticeDAO noticeDAO;

	@Autowired
	OrderDAO orderDAO;

	@Override // 1. 공지사항 글 목록 V
	public void notice_list_action(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_list_action");

		// 해당 페이지 번호 클릭시
		String pageNum = req.getParameter("pageNum");

		// 페이지 처리
		Paging paging = new Paging(pageNum);

		// 전체 게시글 개수
		int total = noticeDAO.noticeCnt();
		System.out.println("total : " + total);
		paging.setTotalCount(total);

		// 1을 클릭하면 1 10, 2를 클릭하면 11 20
		int start = paging.getStartRow();
		int end = paging.getEndRow();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);

		// 게시글 목록
		List<NoticeDTO> list = noticeDAO.notice_list_admin(map);

		// jsp로 처리 결과 전달(request 또는 session으로)
		model.addAttribute("list", list);
		model.addAttribute("paging", paging);
	}

	@Override // 2. 공지사항 글 상세 V
	public void notice_read_action(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_read_action");

		int notice_no = Integer.parseInt(req.getParameter("notice_no"));
		System.out.println("notice_no : "+notice_no);

		noticeDAO.plusReadCnt(notice_no);
		NoticeDTO dto = noticeDAO.notice_read(notice_no);

		String content = dto.getContent();
		if(content != null) {
			content = content.replace("\n", "<br>");
		}
		dto.setContent(content);

		model.addAttribute("dto", dto);
		model.addAttribute("notice_no", notice_no);
	}

	@Override // 3. 공지사항 등록 V
	public void notice_insert_action(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_insert_action");

		NoticeDTO dto = new NoticeDTO();
		dto.setTitle(req.getParameter("title"));
		dto.setContent(req.getParameter("content"));
		dto.setWriter((String)req.getSession().getAttribute("sessionNick"));

		int cnt = noticeDAO.notice_insert(dto);
		System.out.println(dto);
		System.out.println("INSERT(성공:1,실패:0) : " + cnt);

		model.addAttribute("cnt", cnt);
		model.addAttribute("notice_no", dto.getNotice_no());

	}

	@Override // 4. 공지사항 수정 V
	public void notice_udpate_action(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_udpate_action");

		NoticeDTO dto = new NoticeDTO();
		dto.setNotice_no(Integer.parseInt(req.getParameter("notice_no")));
		dto.setTitle(req.getParameter("title"));
		dto.setContent(req.getParameter("content"));

		int updateResult = noticeDAO.notice_update(dto);
		System.out.println("UPDATE(성공:1,실패:0) : " + updateResult);

		model.addAttribute("updateResult", updateResult);
		req.setAttribute("notice_no", dto.getNotice_no());
	}

	@Override // 5. 공지사항 삭제 V
	public void notice_delete_action(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - notice_delete_action");

		int notice_no = Integer.parseInt(req.getParameter("notice_no"));

		int deleteResult = noticeDAO.notice_delete(notice_no);
		System.out.println("DELETE(성공:1,실패:0) : " + deleteResult);

		model.addAttribute("deleteResult", deleteResult);

	}

	@Override // 6. 재고목록 V
	public void productListAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productListAction()");

		// 화면에서 입력받은 값 받아오기
		String pageNum = req.getParameter("pageNum");

		// 페이지 처리
		Paging paging = new Paging(pageNum);

		// 전체 게시글 개수
		int total = productDAO.productCount();
		System.out.println("total : "+total);
		paging.setTotalCount(total);

		int start = paging.getStartRow();
		int end = paging.getEndRow();

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("start", start);
		map.put("end", end);


		// DAO 연결
		List<ProductDTO> list = productDAO.productList(map);
//		System.out.println("list : "+list);

		//  jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		model.addAttribute("list", list);
		model.addAttribute("paging", paging);
	}

	@Override // 7. 재고상세 V
	public void productReadAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productReadAction()");

		//  화면에서 입력받은 값 받아오기
		int p_code = Integer.parseInt(req.getParameter("p_code"));
		String pageNum = req.getParameter("pageNum");
		System.out.println("pageNum : " + pageNum);

		// DAO 연결
		ProductDTO dto = productDAO.productRead(p_code);
		System.out.println("ProductDTO : " + dto);

		// jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		model.addAttribute("dto", dto);
		model.addAttribute("pageNum", pageNum);
	}

	@Override // 8. 재고추가 V
	public void productAddAction(MultipartHttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productAddAction()");

		/* -------------------- 파일처리 추가 Start -------------------- */
		MultipartFile file = req.getFile("p_img");
		System.out.println("file : " + file);

		// 저장경로
		String saveDir = req.getSession().getServletContext().getRealPath("/resources/upload/");
		System.out.println("saveDir : " + saveDir);

		// 저장경로(jsp의 IMG_UPLOAD_DIR)
		String realDir = "D:\\Dev105\\workspace2\\spring_pj_jsr\\src\\main\\webapp\\resources\\upload\\";
		System.out.println("realDir : " + realDir);

		try {
			file.transferTo(new File(saveDir + file.getOriginalFilename()));

			// 파일 IO Stream 생성
			FileInputStream fis = new FileInputStream(saveDir + file.getOriginalFilename());
			FileOutputStream fos = new FileOutputStream(realDir + file.getOriginalFilename());

			int data = 0;

			// 파일이 존재하는 동안 데이터 쓰기
			while((data = fis.read()) != -1) {
				fos.write(data);
			}

			fis.close();
			fos.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		/* -------------------- 파일처리 추가 End -------------------- */

		//  화면에서 입력받은 값 DTO에 담기
		ProductDTO dto = new ProductDTO();
		dto.setP_brand(req.getParameter("p_brand"));
		dto.setP_category(req.getParameter("p_category"));
		dto.setP_name(req.getParameter("p_name"));
		dto.setP_content(req.getParameter("p_content"));
		dto.setP_price(Integer.parseInt(req.getParameter("p_price")));
		dto.setP_qty(Integer.parseInt(req.getParameter("p_qty")));
		dto.setStatus(req.getParameter("status"));

		// 플젝명/upload 파일업로드 경로
		String p_img = "/pj_jsr/resources/upload/" + file.getOriginalFilename(); // 플젝명/경로
		dto.setP_img(p_img);
		System.out.println("서비스에서 설정한 p_img(경로+이름) : " + p_img);
		System.out.println("서비스 dto insert 정보 - " + dto);

		// DAO 연결 - 재고정보 Insert
		int insertCnt = productDAO.productInsert(dto);
		System.out.println("서비스 - insertCnt : "+insertCnt);

		//  jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		model.addAttribute("insertCnt", insertCnt);

	}

	@Override // 9. 재고수정 V
	public void productUpdateAction(MultipartHttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productUpdateAction()");

		String pageNum = req.getParameter("pageNum");
		System.out.println("pageNum : " + pageNum);

		// 기존파일이름
		String old_file = req.getParameter("old_p_img");
		System.out.println("기존 파일명 old_file : " + old_file);

		/* -------------------- 파일처리 추가 Start -------------------- */
		MultipartFile new_file = req.getFile("new_p_img"); // 수정파일이름
		System.out.println("수정할 파일명 new_file : " + new_file);

		// 저장경로
		String saveDir = req.getSession().getServletContext().getRealPath("/resources/upload/");
		System.out.println("saveDir : " + saveDir);

		// 저장경로(jsp의 IMG_UPLOAD_DIR)
		String realDir = "D:\\Dev105\\workspace2\\spring_pj_jsr\\src\\main\\webapp\\resources\\upload\\";
		System.out.println("realDir : " + realDir);

		String p_img = "";

		// 이미지를 수정하려면 p_img에 등록
		if(new_file.getOriginalFilename() != null && new_file.getOriginalFilename() != "") {

			try {

				new_file.transferTo(new File(saveDir + new_file.getOriginalFilename()));

				// 파일 IO Stream 생성
				FileInputStream fis = new FileInputStream(saveDir + new_file.getOriginalFilename());
				FileOutputStream fos = new FileOutputStream(realDir + new_file.getOriginalFilename());

				int data = 0;

				// 파일이 존재하는 동안 데이터 쓰기
				while((data = fis.read()) != -1) {
					fos.write(data);
				}

				fis.close();
				fos.close();

			} catch (IOException e) {
				e.printStackTrace();
			}

			p_img = "/pj_jsr/resources/upload/" + new_file.getOriginalFilename();
			System.out.println("[최종] 새 이미지명 : " + p_img);

		} else {

			p_img = old_file;
			System.out.println("[최종] 기존 이미지명 : " + p_img);

		}
		/* -------------------- 파일처리 추가 End -------------------- */

		//  화면에서 입력받은 값 받아오기
		ProductDTO dto = new ProductDTO();
		dto.setP_code(Integer.parseInt(req.getParameter("p_code")));
		dto.setP_brand(req.getParameter("p_brand"));
		dto.setP_category(req.getParameter("p_category"));
		dto.setP_name(req.getParameter("p_name"));
		dto.setP_content(req.getParameter("p_content"));
		dto.setP_price(Integer.parseInt(req.getParameter("p_price")));
		dto.setP_qty(Integer.parseInt(req.getParameter("p_qty")));
		dto.setP_option(req.getParameter("p_option"));
		dto.setStatus(req.getParameter("status"));
		dto.setP_img(p_img);

		System.out.println("수정된 DTO 정보 : " + dto);

		int updateCnt = productDAO.productUpdate(dto);
		System.out.println("서비스 updateCnt : "+updateCnt);

		//  jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		model.addAttribute("updateCnt", updateCnt);
		model.addAttribute("pageNum", pageNum);
		model.addAttribute("p_code", dto.getP_code());

	}

	@Override // 10. 재고삭제 V
	public void productDeleteAction(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - productDeleteAction()");

		String pageNum = req.getParameter("pageNum");
		System.out.println("pageNum : " + pageNum);

		//  화면에서 입력받은 값 받아오기
		int p_code = Integer.parseInt(req.getParameter("p_code"));

		int deleteCnt = productDAO.productDelete(p_code);
		System.out.println("서비스 deleteCnt : "+deleteCnt);

		//  jsp로 처리 결과 전달(request나 session으로 처리 결과를 저장 후 전달)
		model.addAttribute("deleteCnt", deleteCnt);
		req.setAttribute("pageNum", pageNum);

	}

	@Override // 11. 재고검색
	public void productSearchList(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println(" 재고 검색 - 미구현");

	}

	@Override // 12. 주문목록
	public void orderList(HttpServletRequest req, Model model)
			throws ServletException, IOException {
		System.out.println("서비스 - orderList");

		String pageNum = req.getParameter("pageNum");

		//  페이지 처리
		Paging paging = new Paging(pageNum);

		// 전체 주문 개수
		int total = orderDAO.orderCount();
		System.out.println("total : "+total);
		paging.setTotalCount(total);

		int start = paging.getStartRow();
		int end = paging.getEndRow();

		Map<String, Object> orderMap = new HashMap<String, Object>();
		orderMap.put("start", start);
		orderMap.put("end", end);

		List<OrderDTO> list = orderDAO.OrderList(orderMap);
		//System.out.println("list : "+list);
//		int totalSales = orderDAO.totalOrderSales();

		model.addAttribute("list", list);
		model.addAttribute("paging", paging);
//		model.addAttribute("totalSales", totalSales);

	}

	@Override // 13. 구매승인
	public void orderConfirm(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("서비스 - orderConfirm");

		int order_no = Integer.parseInt(req.getParameter("order_no"));
		int p_code = Integer.parseInt(req.getParameter("p_code"));
		String state = "구매승인";

		Map<String, Object> orderMap = new HashMap<String, Object>();
		orderMap.put("order_no", order_no);
		orderMap.put("state", state);

		int updateResult = orderDAO.updateState(orderMap);
		System.out.println("구매승인으로 상태변경 - [1:성공 0:실패] : " + updateResult);

		Map<String, Object> productMap = new HashMap<String, Object>();
		productMap.put("order_no", order_no);
		productMap.put("p_code", p_code);

		int minusStockResult = productDAO.minusStock(productMap);
		System.out.println("재고 감소 - [1:성공 0:실패] : " + minusStockResult);

		int result = 0;
		// 구매승인과 재고감소처리가 완료 되었을 경우에만 구매 승인 완료로 처리
		if(updateResult==1 && minusStockResult==1) result = 1;

		System.out.println("구매승인으로 상태변경 및 재고감소 완료 - [1:성공 0:실패] : " + result);
		model.addAttribute("orderResult", result);

	}

	@Override // 14. 구매거절
	public void orderReject(HttpServletRequest req, Model model) throws ServletException, IOException {
		System.out.println("서비스 - orderReject");

		int order_no = Integer.parseInt(req.getParameter("order_no"));
		String state = "구매거절";

		Map<String, Object> orderMap = new HashMap<String, Object>();
		orderMap.put("order_no", order_no);
		orderMap.put("state", state);

		int updateResult = orderDAO.updateState(orderMap);
		System.out.println("구매거절으로 상태변경 - [1:성공 0:실패] : " + updateResult);

		model.addAttribute("orderResult", updateResult);

	}

	@Override // 15. 환불목록
	public void refundList(HttpServletRequest req, Model model)
			throws ServletException, IOException{
		System.out.println("서비스 - refundList (미완성)");

	}

	@Override // 16. 환불승인
	public void refundConfirm(HttpServletRequest req, Model model)
			throws ServletException, IOException{
		System.out.println("서비스 - refundConfirm");

		int order_no = Integer.parseInt(req.getParameter("order_no"));
		int o_qty = Integer.parseInt(req.getParameter("o_qty"));
		int o_total = Integer.parseInt(req.getParameter("o_total"));
		int p_code = Integer.parseInt(req.getParameter("p_code"));

		String state = "환불승인";

		Map<String, Object> orderMap = new HashMap<String, Object>();
		orderMap.put("order_no", order_no);
		orderMap.put("o_qty", o_qty);
		orderMap.put("state", state);
		orderMap.put("o_total", o_total);

		int refundResult = orderDAO.updateState(orderMap);
		System.out.println("환불승인으로 상태변경 - [1:성공 0:실패] : " + refundResult);

		Map<String, Object> productMap = new HashMap<String, Object>();
		productMap.put("order_no", order_no);
		productMap.put("p_code", p_code);

		int plusStockResult = productDAO.plusStock(productMap);
		System.out.println("재고 감소 - [1:성공 0:실패] : " + plusStockResult);

		int result = 0;

		// 환불승인과 재고감소처리가 완료 되었을 경우에만 환불 승인 완료로 처리
		if(refundResult == 1 && plusStockResult == 1) result = 1;

		System.out.println("환불승인으로 상태변경 및 재고증가 완료 - [1:성공 0:실패] : " + result);
		model.addAttribute("orderResult", result);
	}

	@Override // 17. 환불거절
	public void refundReject(HttpServletRequest req, Model model)
			throws ServletException, IOException{
		System.out.println("서비스 - refundReject");

		int order_no = Integer.parseInt(req.getParameter("order_no"));
		String state = "환불거절";

		Map<String, Object> orderMap = new HashMap<String, Object>();
		orderMap.put("order_no", order_no);
		orderMap.put("state", state);

		int updateResult = orderDAO.updateState(orderMap);
		System.out.println("환불거절으로 상태변경 - [1:성공 0:실패] : " + updateResult);

		model.addAttribute("orderResult", updateResult);
	}

	// 18. 결산
	@Override
	public void orderSales(HttpServletRequest req, Model model)
			throws ServletException, IOException{
		System.out.println("서비스 - order_sales");

		List<SalesDTO> list = new ArrayList<SalesDTO>();
		list = orderDAO.totalOrderSales();

		model.addAttribute("list", list);

	}
}

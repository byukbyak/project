package com.spring.pj_jsr.service;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

// 로그인 제한시,
public class UserDeniedHandler implements AccessDeniedHandler{

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response,
			AccessDeniedException accessDeniedException) throws IOException, ServletException {
		System.out.println("UserDeniedHandler - handle()진입 ");
		System.out.println("sessionId : " + request.getSession().getAttribute("sessionId"));

		request.setAttribute("errMsg", "관리자만 접근할 수 있다는 권한에러 도출");

		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/common/error.jsp");
		dispatcher.forward(request, response);
	}

}

package com.spring.pj_jsr.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.pj_jsr.dto.CartDTO;
import com.spring.pj_jsr.dto.OrderDTO;
import com.spring.pj_jsr.dto.SalesDTO;

@Repository
public class OrderDAOImpl implements OrderDAO {

	@Autowired
	SqlSession sqlSession;

	/* -------------------- [ 장바구니 ] -------------------- */

	@Override // 1. 장바구니 목록 불러오기
	public List<CartDTO> cart_read(String strId) {
		System.out.println("DAO - cart_read");
		return sqlSession.getMapper(OrderDAO.class).cart_read(strId);
	}

	@Override // 2. 장바구니 담기
	public int cart_add(Map<String, Object> map) {
		System.out.println("DAO - cart_add");
		return sqlSession.getMapper(OrderDAO.class).cart_add(map);
	}

	@Override // 3. 장바구니 개별 삭제
	public int deleteCartItem(int c_num){
		System.out.println("DAO - deleteCartItem");
		return sqlSession.getMapper(OrderDAO.class).deleteCartItem(c_num);
	}

	@Override // 3-1. 장바구니 개별 삭제
	public int deleteCartItemArr(String[] c_num_arr){
		System.out.println("DAO - deleteCartItem");

		int deleteResult = 0;
		int deleteCount = 0;

		if(deleteResult == 0) {
			for (String c_num_ex : c_num_arr) {
				System.out.println("DAO - c_num_ex : " + c_num_ex);
				int c_num = Integer.parseInt(c_num_ex);
				deleteCount += sqlSession.delete("com.spring.pj_jsr.dao.OrderDAO.deleteCartItem", c_num);
			}
			System.out.println("DAO - deleteCount : " + deleteCount);
			deleteResult = 1;
		}
		System.out.println("DAO - deleteResult : " + deleteResult);
		return deleteResult;

	}

	@Override // 4. 장바구니 비우기
	public int deleteCartAll(){
		System.out.println("DAO - deleteCartAll");
		// 장바구니 등록 결과 [ 성공:1 실패:0 ]
		return sqlSession.getMapper(OrderDAO.class).deleteCartAll();
	}

	@Override // 5. 장바구니에서 선택한 목록
	public List<CartDTO> selectPayList(String[] c_num_arr){
		System.out.println("DAO - selectPayList");

		List<CartDTO> selectList = new ArrayList<CartDTO>();
		CartDTO dto = null;

		for (String c_num_ex : c_num_arr) {
			int c_num = Integer.parseInt(c_num_ex);
			dto = new CartDTO();
			dto = sqlSession.selectOne("com.spring.pj_jsr.dao.OrderDAO.selectPayList", c_num);
			selectList.add(dto);
		}
		System.out.println("DAO - selectList : " + selectList);
		return selectList;
	}

	@Override // 6. 장바구니 수량변경
	public int updateCartItemAmount(Map<String, Object> map) {
		System.out.println("DAO - updateCartItemAmount");
		return sqlSession.getMapper(OrderDAO.class).updateCartItemAmount(map);
	}

	@Override // 7. 전체 주문목록 조회 - 관리자
	public List<OrderDTO> OrderList(Map<String, Object> map) {
		System.out.println("DAO - selectOrderList");
		return sqlSession.getMapper(OrderDAO.class).OrderList(map);
	}

	@Override // 8. 특정고객 주문조회
	public List<OrderDTO> selectOrderList(Map<String, Object> map) {
		System.out.println("DAO - selectOrderList");
		return sqlSession.getMapper(OrderDAO.class).selectOrderList(map);
	}

	@Override // 9. 주문 상태에 따른 목록 조회
	public List<OrderDTO> selectOrderStatuslist(Map<String, Object> map) {
		System.out.println("DAO - selectOrderRlist");
		return sqlSession.getMapper(OrderDAO.class).selectOrderStatuslist(map);
	}

	@Override // 10. 주문 상태에 따른 목록 조회
	public List<OrderDTO> selectRefundStatuslist(Map<String, Object> map) {
		System.out.println("DAO - selectOrderRlist");
		return sqlSession.getMapper(OrderDAO.class).selectRefundStatuslist(map);
	}

	@Override // 11. 결제 후 주문 등록
	public int insertOrder(List<OrderDTO> olist) {
		System.out.println("DAO - insertOrder");

		int insertResult = 0;
		int insertCount = 0;

		if(insertResult == 0) {
			for (OrderDTO dto : olist) {
				System.out.println("DAO - olist : " + olist);
				insertCount += sqlSession.delete("com.spring.pj_jsr.dao.OrderDAO.insertOrder", dto);
			}
			System.out.println("DAO - insertCount : " + insertCount);
			insertResult = 1;
		}
		System.out.println("DAO - insertResult : " + insertResult);
		return insertResult;
	}

	@Override // 12. 상태 변경
	public int updateState(Map<String, Object> map) {
		System.out.println("DAO - updateState");
		return sqlSession.getMapper(OrderDAO.class).updateState(map);
	}

	@Override // 13. 전체 주문 총 개수
	public int selectOrderAllTotal() {
		System.out.println("DAO - selectOrderAllTotal");
		return sqlSession.getMapper(OrderDAO.class).selectOrderAllTotal();
	}

	@Override // 14. 주문 총 개수
	public int orderCount() {
		System.out.println("DAO - selectOrderTotal");
		return sqlSession.getMapper(OrderDAO.class).orderCount();
	}

	@Override // 15. 고객 주문 총 개수
	public int customerOrderCount(String id) {
		System.out.println("DAO - selectOrderTotal");
		return sqlSession.getMapper(OrderDAO.class).customerOrderCount(id);
	}
	@Override // 16. 고객 환불 총 개수
	public int selectRefundTotal(String id) {
		System.out.println("DAO - selectRefundTotal");
		return sqlSession.selectOne("com.spring.pj_jsr.dao.OrderDAO.customerRefundCount", id);
	}

	@Override // 17. 환불 총 개수
	public int refundTotalCount() {
		System.out.println("DAO - selectRefundTotal");
		return sqlSession.getMapper(OrderDAO.class).refundTotalCount();
	}

	@Override // 18. 바로구매 ORDER_TBL (1건) INSERT
	public int now_buy(OrderDTO dto) {
		System.out.println("DAO - now_buy");
		return sqlSession.getMapper(OrderDAO.class).now_buy(dto);
	}

	@Override // 19. 결산
	public List<SalesDTO> totalOrderSales() {
		System.out.println("DAO - totalOrderSales");
		return sqlSession.getMapper(OrderDAO.class).totalOrderSales();
	}

}

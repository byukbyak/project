package com.spring.pj_jsr.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.pj_jsr.dto.ProductDTO;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	SqlSession sqlSession;

	@Override // 1. 재고/상품 개수 구하기
	public int productCount() {
		System.out.println("DAO - productCount()");
		return sqlSession.getMapper(ProductDAO.class).productCount();
	}

	@Override // 2. 재고/상품 목록 조회
	public List<ProductDTO> productList(Map<String, Object> map) {
		System.out.println("DAO - productList()");

		return sqlSession.getMapper(ProductDAO.class).productList(map);
	}

	@Override // 3. 카테고리별 재고/상품 목록
	public List<ProductDTO> productListCategory(Map<String, Object> map) {
		System.out.println("DAO - productListCategory()");

		return sqlSession.getMapper(ProductDAO.class).productListCategory(map);
	}

	@Override // 4. 재고/상품 상세 조회
	public ProductDTO productRead(int p_code) {
		System.out.println("DAO - getProductDetail()");
		return sqlSession.getMapper(ProductDAO.class).productRead(p_code);
	}

	@Override // 5. 재고/상품 등록
	public int productInsert(ProductDTO dto) {
		System.out.println("DAO - productInsert()");
		// 재고/상품 등록 결과 [ 성공:1 실패:0 ]
		return sqlSession.getMapper(ProductDAO.class).productInsert(dto);
	}

	@Override // 6. 재고/상품 수정
	public int productUpdate(ProductDTO dto) {
		System.out.println("DAO - productUpdate()");
		// 재고/상품 수정 결과 [ 성공:1 실패:0 ]
		return sqlSession.getMapper(ProductDAO.class).productUpdate(dto);
	}

	@Override // 7. 재고/상품 삭제
	public int productDelete(int p_code) {
		System.out.println("DAO - productDelete()");
		// 재고/상품 삭제 결과 [ 성공:1 실패:0 ]
		return sqlSession.getMapper(ProductDAO.class).productDelete(p_code);
	}

	@Override // 8-1. 검색한 재고/상품 총 개수 - ALL
	public int searchTotalAll(String keyword) {
		System.out.println("DAO - searchTotalAll");
		return sqlSession.getMapper(ProductDAO.class).searchTotalAll(keyword);
	}

	@Override // 8-2. 검색한 재고/상품 총 개수 - Category
	public int searchTotalCategory(Map<String, Object> map) {
		System.out.println("DAO - searchTotalCategory");
		return sqlSession.getMapper(ProductDAO.class).searchTotalCategory(map);
	}

	@Override // 9-1 . 재고/상품 검색 - All
	public List<ProductDTO> searchProductAll(Map<String, Object> map) {
		System.out.println("DAO - searchProductAll");
		return sqlSession.getMapper(ProductDAO.class).searchProductAll(map);
	}

	@Override // 9-2 . 재고/상품 검색 - Category
	public List<ProductDTO> searchProductCategory(Map<String, Object> map) {
		System.out.println("DAO - searchProductAll");
		return sqlSession.getMapper(ProductDAO.class).searchProductCategory(map);
	}

	@Override // 10. 재고 증가
	public int plusStock(Map<String, Object> map) {
		System.out.println("DAO - plusStock");
		// 재고 수정 결과 [ 성공:1 실패:0 ]
		return sqlSession.getMapper(ProductDAO.class).plusStock(map);
	}

	@Override // 11. 재고 감소
	public int minusStock(Map<String, Object> map) {
		System.out.println("DAO - minusStock");
		// 재고 수정 결과 [ 성공:1 실패:0 ]
		return sqlSession.getMapper(ProductDAO.class).minusStock(map);
	}

}

package com.spring.pj_jsr.dto;

public class AdminDTO {

	private int admin_no;
	private String admin_id;
	private String admin_pw;
	private String admin_nick;
	private String authority; // 권한 등급 DEFAULT 'ROLE_ADMIN'
	private String enabled = "1";

	public AdminDTO() {}

	public AdminDTO(int admin_no, String admin_id, String admin_pw, String admin_nick) {
		this.admin_no = admin_no;
		this.admin_id = admin_id;
		this.admin_pw = admin_pw;
		this.admin_nick = admin_nick;
	}

	public int getAdmin_no() {
		return admin_no;
	}

	public void setAdmin_no(int admin_no) {
		this.admin_no = admin_no;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}

	public String getAdmin_pw() {
		return admin_pw;
	}

	public void setAdmin_pw(String admin_pw) {
		this.admin_pw = admin_pw;
	}

	public String getAdmin_nick() {
		return admin_nick;
	}

	public void setAdmin_nick(String admin_nick) {
		this.admin_nick = admin_nick;
	}
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	public String getEnabled() {
		return enabled;
	}
	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	@Override
	public String toString() {
		return "[AdminDTO 클래스 정보]"
				+ "\n admin_no : " + admin_no
				+ "\n admin_id : " + admin_id
				+ "\n admin_pw : " + admin_pw
				+ "\n admin_nick : " + admin_nick
				+ "\n authority : " + authority
				+ "\n enabled : " + enabled;
	}

}

/*
	CREATE TABLE admin_tbl (
	    admin_no NUMBER CONSTRAINT admin_no_pk PRIMARY KEY,
	    admin_id VARCHAR2(20) CONSTRAINT admin_id_unn NOT NULL UNIQUE,
	    admin_pw VARCHAR2(20) CONSTRAINT admin_pw_nn NOT NULL,
	    admin_nick VARCHAR2(20) CONSTRAINT admin_nick_unn NOT NULL UNIQUE,
	    authority   VARCHAR2(30)    DEFAULT 'ROLE_ADMIN'
	);
*/
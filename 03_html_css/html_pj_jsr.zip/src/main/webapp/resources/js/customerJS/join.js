

function gotomain(){
    
}
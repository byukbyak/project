/**
 * 
 */


// let button = () => {
// 	alert('로그인이 완료되었습니다.');
// 	location.href="document.";
// }